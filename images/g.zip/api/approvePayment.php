<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['addAmmount'],$_POST['token'])){
	$id = str2dec($_POST['id']);
	if(token2trust($_POST['token']) && $id){
		$addAmmount = $_POST['addAmmount'];
		$checkList = mysqli_query($conn, "SELECT * FROM `payments` WHERE `id` = '$id'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$paymentInfo = mysqli_fetch_array($checkList);
			$userID = $paymentInfo['userID']; $amount = $paymentInfo['amount'];
			$checkUserList = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$userID'");
			$totalUserList = mysqli_num_rows($checkUserList);
			if($totalUserList > 0){
				$userInfo = mysqli_fetch_array($checkUserList);
				$balance = $userInfo['balance']; $newBalance = $balance + $addAmmount;
				$updateBalance = mysqli_query($conn, "UPDATE `users` SET `balance` = '$newBalance' WHERE `users`.`id` = $userID");
				if($updateBalance){
					$result['success'] = true;
					$result['message'] = 'Approved successfully!';
					if($addAmmount == $amount){
						mysqli_query($conn, "UPDATE `payments` SET `status` = 'ADDED' WHERE `payments`.`id` = $id");
					}else{
						mysqli_query($conn, "UPDATE `payments` SET `status` = 'REJECTED' WHERE `payments`.`id` = $id");
						mysqli_query($conn, "INSERT INTO `payments` (`id`, `userID`, `number`, `trxID`, `amount`, `type`, `status`, `date`) VALUES (NULL, '$userID', 'UnKnown', 'BY ADMIN', '$addAmmount', 'CUSTOM', 'ADDED', current_timestamp())");
					}
				}else{
					$result['success'] = false;
					$result['message'] = 'Something went worng!';
				}
			}else{
				$result['success'] = false;
				$result['message'] = 'Invalid user ID!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid payment ID!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>