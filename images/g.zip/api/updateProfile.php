<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['userID'],$_POST['name'],$_POST['email'],$_POST['number'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$userID = $_SESSION['userID'];
		$name = str_replace("'","\'",$_POST['name']);
		$email = str_replace("'","\'",$_POST['email']);
		$number = str_replace("'","\'",$_POST['number']);
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` != '$userID' AND `email` = '$email'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$result['success'] = false;
			$result['message'] = 'Email already exists!';
		}else{
			$updateProfile = mysqli_query($conn, "UPDATE `users` SET `name` = '$name', `email` = '$email', `mobile` = '$number' WHERE `users`.`id` = $userID");
			if($updateProfile){
				$result['success'] = true;
				$result['message'] = 'Update successfully!';				
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>