<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['token'])){
	$userID = str2dec($_POST['id']);
	if(token2trust($_POST['token']) && $userID){
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$userID'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$updateStatus = mysqli_query($conn, "UPDATE `users` SET `status` = '0' WHERE `users`.`id` = $userID");
			if($updateStatus){
				$result['success'] = true;
				$result['message'] = 'Unverified successfully!';				
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid user ID!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>