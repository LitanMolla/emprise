<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_POST['email'],$_POST['password'],$_POST['remember'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$remember = $_POST['remember'];
		$password = md5($_POST['password']);
		$email = str_replace("'","\'",$_POST['email']);
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$listData = mysqli_fetch_array($checkList);
			if($control['approval']){
				if($listData['status'] == "1"){
					$result['success'] = true;
					$_SESSION['userID'] = $listData['id'];
					$result['message'] = 'Logged successfully!';
					if($remember == "YES"){
						setcookie('userID', str2enc($listData['id']), time()+60*60*24*30, '/');
					}
				}else{
					$result['success'] = false;
					$result['message'] = "Unverified Account!";
					$result['appMsg'] = $control['appMsg'];
				}
			}else{
				$result['success'] = true;
				$_SESSION['userID'] = $listData['id'];
				$result['message'] = 'Logged successfully!';
				if($remember == "YES"){
					setcookie('userID', str2enc($listData['id']), time()+60*60*24*30, '/');
				}
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid email or password!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>