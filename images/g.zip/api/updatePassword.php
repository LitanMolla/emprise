<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['userID'],$_POST['oldPassword'],$_POST['newPassword'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$userID = $_SESSION['userID'];
		$oldPassword = md5($_POST['oldPassword']);
		$newPassword = md5($_POST['newPassword']);
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$userID' AND `password` = '$oldPassword'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$updateProfile = mysqli_query($conn, "UPDATE `users` SET `password` = '$newPassword' WHERE `users`.`id` = $userID");
			if($updateProfile){
				$result['success'] = true;
				$result['message'] = 'Update successfully!';				
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid old password!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>