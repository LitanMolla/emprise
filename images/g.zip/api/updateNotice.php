<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['lobMsg'],$_POST['notMsg'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$lobMsg = base64_encode($_POST['lobMsg']);
		$notMsg = base64_encode($_POST['notMsg']);
		$updateApproval = mysqli_query($conn, "UPDATE `control` SET `lobMsg` = '$lobMsg', `notMsg` = '$notMsg' WHERE `control`.`id` = 1;");
		if($updateApproval){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>