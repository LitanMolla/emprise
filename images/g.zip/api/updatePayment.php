<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['minRecharge'],$_POST['rechargeType'],$_POST['BKS_URL'],$_POST['BKS_USER'],$_POST['BKS_PASS'],$_POST['BKS_KEY'],$_POST['BKS_SEC'],$_POST['recMsg'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$minRecharge = $_POST['minRecharge'];
		$rechargeType = $_POST['rechargeType'];
		$BKS_URL = $_POST['BKS_URL'];
		$BKS_USER = $_POST['BKS_USER'];
		$BKS_PASS = $_POST['BKS_PASS'];
		$BKS_KEY = $_POST['BKS_KEY'];
		$BKS_SEC = $_POST['BKS_SEC'];
		$recMsg = str_replace("'","\'",$_POST['recMsg']);
		if($rechargeType == "auto"){
			$updatePayment = mysqli_query($conn, "UPDATE `control` SET `minRecharge` = '$minRecharge', `rechargeType` = '$rechargeType', `BKS_URL` = '$BKS_URL', `BKS_USER` = '$BKS_USER', `BKS_PASS` = '$BKS_PASS', `BKS_KEY` = '$BKS_KEY', `BKS_SEC` = '$BKS_SEC', `recMsg` = '$recMsg' WHERE `control`.`id` = 1;");
		}else{
			$updatePayment = mysqli_query($conn, "UPDATE `control` SET `minRecharge` = '$minRecharge', `rechargeType` = '$rechargeType', `recMsg` = '$recMsg' WHERE `control`.`id` = 1;");
		}
		if($updatePayment){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>