<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['server'],$_POST['login'],$_POST['register'],$_POST['cpnale'],$_POST['serMsg'],$_POST['logMsg'],$_POST['regMsg'],$_POST['desMsg'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$server = $_POST['server'];
		$login = $_POST['login'];
		$register = $_POST['register'];
		$cpnale = $_POST['cpnale'];
		$serMsg = str_replace("'","\'",$_POST['serMsg']);
		$logMsg = str_replace("'","\'",$_POST['logMsg']);
		$regMsg = str_replace("'","\'",$_POST['regMsg']);
		$desMsg = str_replace("'","\'",$_POST['desMsg']);
		$updateServer = mysqli_query($conn, "UPDATE `control` SET `login` = '$login', `register` = '$register', `server` = '$server', `cpnale` = '$cpnale', `logMsg` = '$logMsg', `regMsg` = '$regMsg', `serMsg` = '$serMsg', `desMsg` = '$desMsg' WHERE `control`.`id` = 1;");
		if($updateServer){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';
			if($server){$ser = "ON";}else{$ser = "OFF";}
			if($login){$log = "ON";}else{$log = "OFF";}
			if($register){$reg = "ON";}else{$reg = "OFF";}
			newAdminServerUpdateNotic("*__Server_Update__*".PHP_EOL.PHP_EOL."*Server:* ".$ser.PHP_EOL."*Login:* ".$log.PHP_EOL."*Register:* ".$reg.PHP_EOL."*Cpnale:* ".$domain.$cpnale);
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>