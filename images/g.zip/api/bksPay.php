<?php
include "../assist/setting/index.php";
include "../assist/setting/autoLogin.php";

if(isset($_GET['status'],$_GET['paymentID'],$_SESSION['userID'])){
	$status = $_GET['status'];
	$paymentID = $_GET['paymentID'];
	if($status == 'success'){
		$paymentDetils = getPaymentDetils($paymentID);
		if($paymentDetils != null){
			if($paymentDetils['success']){
				$userID = $user['id'];
				$userName = $user['name'];
				$userBalance = $user['balance'];
				$trxID = $paymentDetils['trxID'];
				$amount = $paymentDetils['amount'];
				$payerReference = $paymentDetils['payerReference'];
				$customerMsisdn = $paymentDetils['customerMsisdn'];
				$merchantInvoiceNumber = $paymentDetils['merchantInvoiceNumber'];
				$paymentExecuteTime = $paymentDetils['paymentExecuteTime'];
				
				newPaymentNotic($userID,$userName,$customerMsisdn,$trxID,$amount,"AUTO");
				mysqli_query($conn, "INSERT INTO `payments` (`id`, `userID`, `number`, `trxID`, `amount`, `type`, `status`, `date`) VALUES (NULL, '$userID', '$customerMsisdn', '$trxID', '$amount', 'AUTO', 'ADDED', current_timestamp())");
				mysqli_query($conn, "INSERT INTO `bks` (`id`, `userID`, `userName`, `paymentID`, `payerReference`, `customerMsisdn`, `trxID`, `amount`, `merchantInvoiceNumber`, `paymentExecuteTime`) VALUES (NULL, '$userID', '$userName', '$paymentID', '$payerReference', '$customerMsisdn', '$trxID', '$amount', '$merchantInvoiceNumber', '$paymentExecuteTime')");
				
				$newBalance = intval($userBalance) + intval($amount);
				$addBalance = mysqli_query($conn, "UPDATE `users` SET `balance` = '$newBalance' WHERE `users`.`id` = $userID");
				if($addBalance){
					header('location: '.$domain.'msg&trxid='.str2enc($trxID)); die();
				}else{
					header('location: '.$domain.'msg&error='.str2enc("Failed to add balance")); die();
				}
			}else{
				header('location: '.$domain.'msg&error='.str2enc($paymentDetils['statusMessage'])); die();
			}
		}else{
			header('location: '.$domain.'msg&error='.str2enc("AuthToken not found")); die();
		}
	}else if($status == 'cancel'){
		header('location: '.$domain.'msg&cancel='.str2enc("Payment cancelled by user")); die();
	}else{
		header('location: '.$domain.'msg&error='.str2enc("Something went wrong")); die();
	}
}else{
	header('location: '.$domain.'login'); die();
}
?>