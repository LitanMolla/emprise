<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['userID'],$_POST['amount'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$amount = $_POST['amount'];
		if($amount > 1){
			$paymentLink = createPaymentLink($amount);
			if($paymentLink != null){
				$result['success'] = true;
				$result['paymentLink'] = $paymentLink;
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went wrong!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid amount!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>