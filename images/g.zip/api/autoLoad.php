<?php
$result = [];
include "../assist/setting/index.php";
define('_PROXY_', file_get_contents('/home/systemma/private_api/proxy/proxy.txt'));

function getBdownloadBRN($brn){
	$result = [];
	$ch = curl_init();
	$postData = http_build_query(['dob_number' => $brn, 'submit' => true]);
	curl_setopt($ch, CURLOPT_URL, 'https://bdownload.online/includes/all_dob.php');
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER , 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		'Content-Type: application/x-www-form-urlencoded',
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$content = curl_exec($ch);
	curl_close($ch);
	
	if(!empty($content)){
		$data = json_decode($content, true);
		if(isset($data['personNameBn'], $data['personNameEn'])){
			if($data['personNameBn'] != '' && $data['personNameEn'] != ''){
				$result['success'] = true;
				$result['data'] = $data;
				$result['msg'] = 'Info found!';
			}else{
				$result['success'] = false;
				$result['msg'] = 'Info not found!';
			}
		}else{
			$result['success'] = false;
			$result['msg'] = 'Server Error!';
		}
	}else{
		$result['success'] = false;
		$result['msg'] = 'Server Down!';
	}
	return $result;
}

function getCaptchaImg($cookie, $captchaDeText){
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, 'https://everify.bdris.gov.bd/DefaultCaptcha/Generate?t='.$captchaDeText);
	curl_setopt($curl, CURLOPT_TIMEOUT, 10);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($curl, CURLOPT_PROXY, _PROXY_);
	curl_setopt($curl, CURLOPT_HTTPHEADER, [
		'Cookie: '.$cookie,
		'Referer: https://everify.bdris.gov.bd',
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$img = curl_exec($curl); curl_close($curl);
	return base64_encode($img);
}

function getAutoloadToken(){
	$data = [];
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, 'https://everify.bdris.gov.bd/');
	curl_setopt($curl, CURLOPT_HEADER, 1);
	curl_setopt($curl, CURLOPT_TIMEOUT, 10);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($curl, CURLOPT_PROXY, _PROXY_);
	curl_setopt($curl, CURLOPT_HTTPHEADER, [
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$session = curl_exec($curl);
	curl_close($curl);
	
	if(!empty($session)){
		$cookie = '';
		if(preg_match("/ASP.NET_SessionId=(.*?);/i", $session, $sessionId)){
			$cookie .= $sessionId[0];
			if(preg_match("/__RequestVerificationToken=(.*?);/i", $session, $requestVerificationToken)){
				$cookie .= $requestVerificationToken[0];
				$html = str_get_html($session);
				$__RequestVerificationToken = $html->find('input[name=__RequestVerificationToken]',0);
				$CaptchaDeText = $html->find('input[name=CaptchaDeText]',0);
				if($__RequestVerificationToken && $CaptchaDeText){
					$data['success'] = true;
					$data['cookie'] = $cookie;
					$data['CaptchaDeText'] = $CaptchaDeText->value;
					$data['__RequestVerificationToken'] = $__RequestVerificationToken->value;
					$data['CaptchaDeImg'] = getCaptchaImg($data['cookie'], $data['CaptchaDeText']);
				}else{
					$data['success'] = false;
					$data['message'] = 'Captcha not found!';
				}
			}else{
				$data['success'] = false;
				$data['message'] = 'Token not found!';
			}
		}else{
			$data['success'] = false;
			$data['message'] = 'Cookies not found!';
		}
	}else{
		$data['success'] = false;
		$data['message'] = 'Empty response from server!';
	}
	return $data;
}

function getAutoloadInfo($brn, $dob, $captcha, $cookie, $CaptchaDeText, $__RequestVerificationToken){
	$data = [];
	$postData = http_build_query(['UBRN' => $brn, 'BirthDate' => $dob, 'CaptchaInputText' => $captcha, 'CaptchaDeText' => $CaptchaDeText, '__RequestVerificationToken' => $__RequestVerificationToken]);

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, 'https://everify.bdris.gov.bd/UBRNVerification/Search');
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_TIMEOUT, 20);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($curl, CURLOPT_PROXY, _PROXY_);
	curl_setopt($curl, CURLOPT_HTTPHEADER, [
		'Cookie: '. $cookie,
		'Referer: https://everify.bdris.gov.bd/UBRNVerification/Search',
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$content = curl_exec($curl);
	curl_close($curl);
	
	if(!empty($content)){
		$html = str_get_html($content);
		$govInfo = $html->find('tbody', 0);
		$personInfo = $html->find('tbody', 1);
		
		if($govInfo){
			$cardInfo = $govInfo->find('tr', 2);
			$basicInfo = $govInfo->find('tr', 4);
			if($cardInfo && $basicInfo){
				$dateOfRegistration = $cardInfo->find('td', 0) ? removeSpace($cardInfo->find('td', 0)->plaintext) : '';
				$officeAddressFirst = $cardInfo->find('td', 1) ? removeSpace($cardInfo->find('td', 1)->plaintext) : '';
				$dateOfIssuance = $cardInfo->find('td', 2) ? removeSpace($cardInfo->find('td', 2)->plaintext) : '';
				$dateOfBirth = $basicInfo->find('td', 0) ? removeSpace($basicInfo->find('td', 0)->plaintext) : '';
				$birthRegistrationNumber = $basicInfo->find('td b', 0) ? removeSpace($basicInfo->find('td b', 0)->plaintext) : '';
				$gendar = $basicInfo->find('td', 2) ? removeSpace($basicInfo->find('td', 2)->plaintext) : '';
			}
		}

		if($personInfo){
			$person = $personInfo->find('tr',0);
			$place = $personInfo->find('tr', 1);
			$father = $personInfo->find('tr', 4);
			$mother = $personInfo->find('tr', 2);
			$fNationality = $personInfo->find('tr', 5);	
			$mNationality = $personInfo->find('tr', 3);		
			if($person && $place && $father && $mother && $fNationality && $mNationality){
				$nameBangla = $person->find('td', 1) ? removeSpace($person->find('td', 1)->plaintext) : '';
				$nameEnglish = $person->find('td', 3) ? removeSpace($person->find('td', 3)->plaintext) : '';
				$birthplaceBangla = $place->find('td', 1) ? removeSpace($place->find('td', 1)->plaintext) : '';
				$birthplaceEnglish = $place->find('td', 3) ? removeSpace($place->find('td', 3)->plaintext) : '';
				$fatherNameBangla = $father->find('td', 1) ? removeSpace($father->find('td', 1)->plaintext) : '';
				$fatherNameEnglish = $father->find('td', 3) ? removeSpace($father->find('td', 3)->plaintext) : '';
				$motherNameBangla = $mother->find('td', 1) ? removeSpace($mother->find('td', 1)->plaintext) : '';
				$motherNameEnglish = $mother->find('td', 3) ? removeSpace($mother->find('td', 3)->plaintext) : '';
				$fatherNationalityBangla = $fNationality->find('td', 1) ? removeSpace($fNationality->find('td', 1)->plaintext) : '';
				$fatherNationalityEnglish = $fNationality->find('td', 3) ? removeSpace($fNationality->find('td', 3)->plaintext) : '';
				$motherNationalityBangla = $mNationality->find('td', 1) ? removeSpace($mNationality->find('td', 1)->plaintext) : '';
				$motherNationalityEnglish = $mNationality->find('td', 3) ? removeSpace($mNationality->find('td', 3)->plaintext) : '';
			}
		}
		
		if(isset($nameBangla, $dateOfBirth)){
			$data['success'] = true;
		    $moreData = getBdownloadBRN($brn);
			$data['officeAddressFirst'] = $officeAddressFirst;
			$data['officeAddressSecond'] = $moreData['success'] ? removeSpace($moreData['data']['officeAddress']) : '';
			$data['birthRegistrationNumber'] = $birthRegistrationNumber;
			$data['barCode'] = getBarCode();
			$data['dateOfRegistration'] = dateNumber($dateOfRegistration);
			$data['dateOfIssuance'] = dateNumber($dateOfIssuance);
			$data['dateOfBirth'] = dateNumber($dateOfBirth);
			$data['gendar'] = $gendar;
			$data['dateOfBirthText'] = dateText($dateOfBirth);
			$data['nameBangla'] = $nameBangla;
			$data['nameEnglish'] = $nameEnglish;
			$data['fatherNameBangla'] = $fatherNameBangla;
			$data['fatherNameEnglish'] = $fatherNameEnglish;
			$data['fatherNationalityBangla'] = $fatherNationalityBangla;
			$data['fatherNationalityEnglish'] = $fatherNationalityEnglish;
			$data['motherNameBangla'] = $motherNameBangla;
			$data['motherNameEnglish'] = $motherNameEnglish;
			$data['motherNationalityBangla'] = $motherNationalityBangla;
			$data['motherNationalityEnglish'] = $motherNationalityEnglish;
			$data['birthplaceBangla'] = $birthplaceBangla.', বাংলাদেশ';
			$data['birthplaceEnglish'] = $birthplaceEnglish.', Bangladesh';
			$data['permanentAddressBangla'] = $moreData['success'] ? removeSpace($moreData['data']['permanetAddressBn']) : '';
			$data['permanentAddressEnglish'] = $moreData['success'] ? removeSpace($moreData['data']['permanetAddressEn']) : '';
		}else{
			$data['success'] = false;
			$data['message'] = 'Couldn\'t find any information!';
		}
	}else{
		$data['success'] = false;
		$data['message'] = 'Empty response from server!';
	}
	return $data;
}

function getIbasToken(){
	$data = [];
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://ibas.finance.gov.bd/acs/general/sales');
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER , 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$content = curl_exec($ch);
	curl_close($ch);
	if(preg_match("/__RequestVerificationToken_L2Fjcw2(.*?);/i", $content, $cookie)){
		$data['success'] = true;
		$data['cookie'] = $cookie[0];
		$html = str_get_html($content);
		$data['CaptchaDeText'] = 'WTH you are looking here?';
		$data['__RequestVerificationToken'] = $html->find('input[name=__RequestVerificationToken]', 0)->value;
		$data['CaptchaDeImg'] = 'iVBORw0KGgoAAAANSUhEUgAAAYEAAACDCAMAAABcOFepAAAAflBMVEX///8AAADh4eHs7OyKioo/Pz/19fXy8vLe3t4YGBgICAgVFRUsLCzu7u76+vrk5OQbGxtdXV3Z2dkgICCDg4Nzc3Ojo6PExMTPz89sbGxUVFRISEi+vr4zMzMvLy+2traampqSkpJubm6qqqo5OTmenp5DQ0NjY2N6enqFhYXGrPmXAAAFhElEQVR4nO2d63aiMBRGqziAVrHitd6tWvX9X3AkQUELIck5jJmub//qKhgP2XLJyYW3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAF5JuNydvlfd1feptey/Opgqml/D+atjqMAbdT8Mdvcnq0aewzGoLTQ6zc9riH9eHYUSb5RUo/7+rcZPRlF98ZEITyI+lw14Z1mHuvvHBfWfsK8zSFvCQRqduwa88a0GNT8wKRHQaCycOw3iwT04Vw30x1kF6n1iVyqg0Vj16o3WkFz9u2qg/5WvP62PlJ8BCWuHFMwGD6G5aCD8eqw+nc9MlQKux+nKheip/l00EH8+157Gh7zObeeP+bg12Z1P3adCvmoPXIfZ/BpK+9B22ECcPKK9r4aGBk7pruOZl/4neP6xbeoMW5dzY70LPd+b3H8xzhk4NoajuO8Hmw8TA+k16PJ4tV8+nAdtF24F/Y0v/9g4ayDYpI3YmYmBRbLbIf5R2MNpsOOOlUL0x1UDGQN9A8LWoGjLKGdg6FSCYuy+ga2+gc8yAbkDdeVOcGPrvoGNtoHkQajsOKJDZsCNx6GUjfsGZtoGltd9mmUbc8mitc8bIYmZ+wb62gauV5pt+dZc88Ir3+ufE7tvINA1cH2sWClavLmTIGQNkMZvMuBV5J+zPpspY3hU/gMDvq6BWaOtfM7cOfkw9JsM7Dtn5fYsaYdzwAhtA1Ggzns27wX9aDQbEfUFpDIywloMsIaobaCKiOlZyGOJ5kY9BmTCj6nxz2bg7VYOMS3hiZzyOzWalHoMiFxkx1kDxJE5MGDNrZwWrRgYsOV+H6DdiGHAmtuxdolpIRiw5dYeULcaqoEBW27jWIgXIRiwZiFLWVADggHbctJhCeSUBAxYMmU6BWDAlhPTKQADlvTkRaikI98EGLAjHZPA0D0GA1ZEa1EEMSEhgAEr9qKEIcfIaRiwIZKdxDOOgGDABtkeHrEEBAMWyGkFXZ6AYMACOWq0dDydGTBgjmwOc41RgQFjIjET58ITDgxYICYP8C3bEIhpPW2m0uoxIFo/HaZZi2QD4hp0sOgYO7YKGYnbemdXuPFieq2jGdhcimOUUwRHxSFODL+EakAkhDo22Yj7BCMTxoZfQjMwVoVShml6mGpAdMxYZUQX7hs424RoekEmGhA3Abs1PWBAQjMg8kGWsydhQEIyIOYI2Q6OOJQeg4JPwy+hGfix7oAO34ZfQjHQtKmTOz2viF4s2wNB4VbP9BmcZqAkCE+2B8KSIzD8EoKBIGmKsa/f1vtvWmRMMxbtDYj56vwTI9Am1iaZjd/lX80GBnQZM56IeWBAk0vykTpmDsOAHmJsRC0Th2FACyGAOka3GBjQ4ZjsX9OkVRjQQHTML1V7BPbRwUA1QoAyUb83zt9kwEAlQoAyHdrsqM8QJTBQhUiHKvuBvANp6AsMqBECjqo9Zl3S4K2aDByYChS80oC4BG0VO4Qip054UOU1EP82A6IdsPN7hXjx9CiT/mtCQDUZWDEVKHidAfnqh2wh2zK2hIB4DdzXmWMaUylhNeDdq606zandaUfJF/EauK+1yLoWMKuBbK3FynGf2n12pF4bXgPZj4Yzh8JqIHuhQMUjfDTXFUB7HwqrgV62tjnbsMo3ZgNZf7l6Fl5gMMCKFBqngSA/HoNx+TtGA9EpF6LqKd97ftGAAtqiuywGIt8PetNt+yGu+T4OfJ+jU4nDQBJiMDs+1utiUhriRV8AMWnKYmD3UfKLuf6foWOVw8D+vVv8UDnsFt6SDQwMab+y9D0fpDIeFoN/hsGAvLvQDKje6FPU9dULm7pQuy5lKbQyFOFydOz1GUIMFCG68jYfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8Q/4CcdlD4UeYRDYAAAAASUVORK5CYII=';
	}else{
		$data['success'] = false;
		$data['msg'] = 'Empty response from server!';
	}
	return $data;
}

function getIbasUBRN($ubrn, $dob, $cookie, $token){
	$data = [];
	$ch = curl_init();
	$postData = json_encode(['ubrn' => $ubrn, 'dob' => $dob]);
	curl_setopt($ch, CURLOPT_URL, 'https://ibas.finance.gov.bd/acs/general/LoadDetailsFromBRN');
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER , 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		'Host: ibas.finance.gov.bd',
		'Cookie: '.$cookie,
		'Content-Type: application/json',
		'X-XSRF-Token: '.$token,
		'Origin: https://ibas.finance.gov.bd',
		'Referer: https://ibas.finance.gov.bd/acs/general/sales',
		'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36'
	]);
	$content = curl_exec($ch);
	curl_close($ch);
	
	$info = json_decode($content, true);
	if(!empty($info)){
		if($info['personname'] != null){
			$data['success'] = true;
			$moreData = getBdownloadBRN($ubrn);
			$data['officeAddressFirst'] = '';
			$data['officeAddressSecond'] = $moreData['success'] ? removeSpace($moreData['data']['officeAddress']) : '';
			$data['birthRegistrationNumber'] = $info['ubrn'];
			$data['barCode'] = getBarCode();
			$data['dateOfRegistration'] = date('d/m/Y');
			$data['dateOfIssuance'] = date('d/m/Y');
			$dateOfBirth = explode('-', $info['dob']);
			$data['dateOfBirth'] = $dateOfBirth[2].'/'.$dateOfBirth[1].'/'.$dateOfBirth[0];
			$data['gendar'] = ($info['sex'] == 'M') ? 'MALE' : 'FEMALE';
			$data['dateOfBirthText'] = dateTextAuto($dateOfBirth[2].'/'.$dateOfBirth[1].'/'.$dateOfBirth[0]);
			$data['nameBangla'] = $info['personname'] ;
			$data['nameEnglish'] = $info['personnameEn'] ;
			$data['fatherNameBangla'] = $info['fathername'] ;
			$data['fatherNameEnglish'] = $info['fathernameEn'] ;
			$data['fatherNationalityBangla'] = $info['fatherNationality'] ;
			$data['fatherNationalityEnglish'] = $info['fatherNationalityEn'] ;
			$data['motherNameBangla'] = $info['mothername'] ;
			$data['motherNameEnglish'] = $info['mothernameEn'] ;
			$data['motherNationalityBangla'] = $info['motherNationality'] ;
			$data['motherNationalityEnglish'] = $info['motherNationalityEn'] ;
			$data['birthplaceBangla'] = $info['placeofbirth'] .', বাংলাদেশ';
			$data['birthplaceEnglish'] = $info['placeofbirthEn'] .', Bangladesh';
			$data['permanentAddressBangla'] = $moreData['success'] ? removeSpace($moreData['data']['permanetAddressBn']) : '';
			$data['permanentAddressEnglish'] = $moreData['success'] ? removeSpace($moreData['data']['permanetAddressEn']) : '';
		}else{
			$data['success'] = false;
			$data['msg'] = 'Couldn\'t find any information!';
		}
	}else{
		$data['success'] = false;
		$data['msg'] = 'Empty response from server!';
	}
	return $data;
}

if(isset($_POST['brn'], $_POST['dob'], $_POST['captcha'], $_POST['cookie'], $_POST['CaptchaDeText'], $_POST['__RequestVerificationToken'], $_POST['token'])){
	if(token2trust($_POST['token'])){
		$result = getIbasUBRN($_POST['brn'], $_POST['dob'], $_POST['cookie'], $_POST['__RequestVerificationToken']);
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else if(isset($_POST['token'])){
	if(token2trust($_POST['token'])){
		$result = getIbasToken();
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>