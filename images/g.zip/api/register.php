<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_POST['name'],$_POST['email'],$_POST['number'],$_POST['password'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$password = md5($_POST['password']);
		$name = str_replace("'","\'",$_POST['name']);
		$email = str_replace("'","\'",$_POST['email']);
		$number = str_replace("'","\'",$_POST['number']);
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$email'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$result['success'] = false;
			$result['message'] = 'Email already exists!';
		}else{
			$newList = mysqli_query($conn, "INSERT INTO `users` (`id`, `name`, `email`, `password`, `mobile`, `balance`, `status`, `cost`, `code`, `sync`, `created`) VALUES (NULL, '$name', '$email', '$password', '$number', '0', '0', '0', '0', current_timestamp(), current_timestamp())");
			if($newList){
				$result['success'] = true;
				$result['message'] = 'Registered successfully!';
				newRegisteredNotic($name,$email,$number);
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>