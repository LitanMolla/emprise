<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['token'])){
	if(token2trust($_POST['token']) && str2dec($_POST['id'])){
		$cardId = str2dec($_POST['id']);
		$getLog = mysqli_query($conn,"SELECT * FROM `cards` WHERE `id` = $cardId");
		$totalLog = mysqli_num_rows($getLog);
		if($totalLog > 0){
			$row = mysqli_fetch_array($getLog);
			$delLog = mysqli_query($conn,"DELETE FROM `cards` WHERE `cards`.`id` = $cardId");
			if($delLog){
				$result['success'] = true;
				$result['message'] = 'সার্টিফিকেট মুছে ফেলা হয়েছে!';
			}else{
				$result['success'] = false;
				$result['message'] = 'সার্টিফিকেট মুছে ফেলতে ব্যর্থ!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'সার্টিফিকেট পাওয়া যায়নি!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>