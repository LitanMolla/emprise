<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['userID'], $_POST['officeAddressFirst'], $_POST['officeAddressSecond'], $_POST['birthRegistrationNumber'], $_POST['barCode'], $_POST['dateOfRegistration'], $_POST['dateOfIssuance'], $_POST['dateOfBirth'], $_POST['gendar'], $_POST['dateOfBirthText'], $_POST['nameBangla'], $_POST['nameEnglish'], $_POST['fatherNameBangla'], $_POST['fatherNameEnglish'], $_POST['fatherNationalityBangla'], $_POST['fatherNationalityEnglish'], $_POST['motherNameBangla'], $_POST['motherNameEnglish'], $_POST['motherNationalityBangla'], $_POST['motherNationalityEnglish'], $_POST['birthplaceBangla'], $_POST['birthplaceEnglish'], $_POST['permanentAddressBangla'], $_POST['permanentAddressEnglish'], $_POST['token'])){
	if(token2trust($_POST['token'])){
		$userID = $_SESSION['userID'];
		$officeAddressFirst = str_replace("'","\'",$_POST['officeAddressFirst']);
		$officeAddressSecond = str_replace("'","\'",$_POST['officeAddressSecond']);
		$birthRegistrationNumber = str_replace("'","\'",$_POST['birthRegistrationNumber']);
		$barCode = str_replace("'","\'",$_POST['barCode']);
		$dateOfRegistration = str_replace("'","\'",$_POST['dateOfRegistration']);
		$dateOfIssuance = str_replace("'","\'",$_POST['dateOfIssuance']);
		$dateOfBirth = str_replace("'","\'",$_POST['dateOfBirth']);
		$gendar = str_replace("'","\'",$_POST['gendar']);
		$dateOfBirthText = str_replace("'","\'",$_POST['dateOfBirthText']);
		$nameBangla = base64_encode($_POST['nameBangla']);
		$nameEnglish = str_replace("'","\'",$_POST['nameEnglish']);
		$fatherNameBangla = base64_encode($_POST['fatherNameBangla']);
		$fatherNameEnglish = str_replace("'","\'",$_POST['fatherNameEnglish']);
		$fatherNationalityBangla = base64_encode($_POST['fatherNationalityBangla']);
		$fatherNationalityEnglish = str_replace("'","\'",$_POST['fatherNationalityEnglish']);
		$motherNameBangla = base64_encode($_POST['motherNameBangla']);
		$motherNameEnglish = str_replace("'","\'",$_POST['motherNameEnglish']);
		$motherNationalityBangla = base64_encode($_POST['motherNationalityBangla']);
		$motherNationalityEnglish = str_replace("'","\'",$_POST['motherNationalityEnglish']);
		$birthplaceBangla = base64_encode($_POST['birthplaceBangla']);
		$birthplaceEnglish = str_replace("'","\'",$_POST['birthplaceEnglish']);
		$permanentAddressBangla = base64_encode($_POST['permanentAddressBangla']);
		$permanentAddressEnglish = base64_encode($_POST['permanentAddressEnglish']);
		if(empty($dateOfBirthText)){$dateOfBirthText = dateTextAuto($dateOfBirth);}
		include "../assist/setting/autoLogin.php";
		if($user['cost']){$cost = $user['cost'];}else{$cost = $control['cost'];}
		if($cost > $user['balance']){
			$result['success'] = false;
			$result['message'] = 'আপনার পর্যাপ্ত পরিমাণ ব্যালেন্স নাই প্লিজ রিচার্জ করুন!';
		}else{
			$newBalance = $user['balance'] - $cost;
			$updateBalance = mysqli_query($conn, "UPDATE `users` SET `balance` = '$newBalance' WHERE `id` = '$userID'");
			if($updateBalance){
				$newBirthList = mysqli_query($conn, "INSERT INTO `cards` (`id`, `userID`, `officeAddressFirst`, `officeAddressSecond`, `birthRegistrationNumber`, `barCode`, `dateOfRegistration`, `dateOfIssuance`, `dateOfBirth`, `gendar`, `dateOfBirthText`, `nameBangla`, `nameEnglish`, `fatherNameBangla`, `fatherNameEnglish`, `fatherNationalityBangla`, `fatherNationalityEnglish`, `motherNameBangla`, `motherNameEnglish`, `motherNationalityBangla`, `motherNationalityEnglish`, `birthplaceBangla`, `birthplaceEnglish`, `permanentAddressBangla`, `permanentAddressEnglish`, `created`) VALUES (NULL, '$userID', '$officeAddressFirst', '$officeAddressSecond', '$birthRegistrationNumber', '$barCode', '$dateOfRegistration', '$dateOfIssuance', '$dateOfBirth', '$gendar', '$dateOfBirthText', '$nameBangla', '$nameEnglish', '$fatherNameBangla', '$fatherNameEnglish', '$fatherNationalityBangla', '$fatherNationalityEnglish', '$motherNameBangla', '$motherNameEnglish', '$motherNationalityBangla', '$motherNationalityEnglish', '$birthplaceBangla', '$birthplaceEnglish', '$permanentAddressBangla', '$permanentAddressEnglish', current_timestamp())");
				if($newBirthList){
					$getBirthList = mysqli_query($conn, "SELECT * FROM `cards` WHERE `userID` = '$userID' AND `nameBangla` = '$nameBangla' AND `birthRegistrationNumber` = '$birthRegistrationNumber' AND `dateOfBirth` = '$dateOfBirth' ORDER BY `id` DESC LIMIT 0,1");
					$birthList = mysqli_fetch_array($getBirthList); $result['success'] = true; $result['balance'] = $newBalance; $result['id'] = str2enc($birthList['id']);
				}else{
					$result['success'] = false;
					$result['message'] = 'সংরক্ষণ করতে ব্যর্থ হয়েছে, আবার চেষ্টা করুন!';
				}
			}else{
				$result['success'] = false;
				$result['message'] = 'কিছু ভুল হয়েছে, আবার চেষ্টা করুন!';
			}
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>