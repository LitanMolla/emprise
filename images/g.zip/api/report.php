<?php
$result = [];
include "../assist/setting/index.php";
include "../assist/setting/autoLogin.php";

if(isset($_SESSION['userID'],$_POST['subject'],$_POST['body'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$userID = $user['id'];
		$body = $_POST['body'];
		$userName = $user['name'];
		$subject = $_POST['subject'];
		
		$report = newReportNotic($userID,$userName,$subject,$body);
		if($report){
			$result['success'] = true;
			$result['message'] = 'Reported successfully!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Report server shutdown. Try again later!';
		}
		
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>