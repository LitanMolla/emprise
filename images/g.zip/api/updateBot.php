<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['notify'],$_POST['TG_ADMIN'],$_POST['TG_BOT'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$notify = $_POST['notify'];
		$TG_ADMIN = $_POST['TG_ADMIN'];
		$TG_BOT = $_POST['TG_BOT'];
		if($notify == "0"){
			$updateBot = mysqli_query($conn, "UPDATE `control` SET `notify` = '$notify' WHERE `control`.`id` = 1;");
		}else{
			$updateBot = mysqli_query($conn, "UPDATE `control` SET `notify` = '$notify', `TG_ADMIN` = '$TG_ADMIN', `TG_BOT` = '$TG_BOT' WHERE `control`.`id` = 1;");
		}
		if($updateBot){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>