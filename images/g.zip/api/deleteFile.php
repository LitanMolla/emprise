<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['token'])){
	$file = str2dec($_POST['id']);
	if(token2trust($_POST['token']) && $file){
		if(file_exists($file)){
			if(unlink($file)){
				$result['success'] = true;
				$result['message'] = 'ফাইল সফলভাবে মুছে ফেলা হয়েছে!';
			}else{
				$result['success'] = false;
				$result['message'] = 'ফাইল মুছে ফেলতে ব্যর্থ!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'ফাইল পাওয়া যায়নি!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>