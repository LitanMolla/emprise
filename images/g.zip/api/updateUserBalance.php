<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['newBalance'],$_POST['setBalance'],$_POST['methodBalance'],$_POST['token'])){
	$userID = str2dec($_POST['id']);
	if(token2trust($_POST['token']) && $userID){
		$newBalance = $_POST['newBalance'];
		$setBalance = $_POST['setBalance'];
		$methodBalance = $_POST['methodBalance'];
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$userID'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$updateBalance = mysqli_query($conn, "UPDATE `users` SET `balance` = '$newBalance' WHERE `users`.`id` = $userID");
			if($updateBalance){
				if($methodBalance == "add"){$status = "ADDED";}else{$status = "REMOVED";}
				$checkListAgain = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$userID'"); $userInfo = mysqli_fetch_array($checkListAgain);
				mysqli_query($conn, "INSERT INTO `payments` (`id`, `userID`, `number`, `trxID`, `amount`, `type`, `status`, `date`) VALUES (NULL, '$userID', 'UnKnown', 'BY ADMIN', '$setBalance', 'CUSTOM', '$status', current_timestamp())");
				$result['success'] = true;
				$result['message'] = 'Updated successfully!';
				$result['balance'] = $userInfo['balance'];
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid user ID!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>