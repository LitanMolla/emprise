<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'], $_POST['officeAddressFirst'], $_POST['officeAddressSecond'], $_POST['birthRegistrationNumber'], $_POST['barCode'], $_POST['dateOfRegistration'], $_POST['dateOfIssuance'], $_POST['dateOfBirth'], $_POST['gendar'], $_POST['dateOfBirthText'], $_POST['nameBangla'], $_POST['nameEnglish'], $_POST['fatherNameBangla'], $_POST['fatherNameEnglish'], $_POST['fatherNationalityBangla'], $_POST['fatherNationalityEnglish'], $_POST['motherNameBangla'], $_POST['motherNameEnglish'], $_POST['motherNationalityBangla'], $_POST['motherNationalityEnglish'], $_POST['birthplaceBangla'], $_POST['birthplaceEnglish'], $_POST['permanentAddressBangla'], $_POST['permanentAddressEnglish'], $_POST['cardID'], $_POST['token'])){
	if(token2trust($_POST['token']) && str2dec($_POST['cardID'])){
		$officeAddressFirst = str_replace("'","\'",$_POST['officeAddressFirst']);
		$officeAddressSecond = str_replace("'","\'",$_POST['officeAddressSecond']);
		$birthRegistrationNumber = str_replace("'","\'",$_POST['birthRegistrationNumber']);
		$barCode = str_replace("'","\'",$_POST['barCode']);
		$dateOfRegistration = str_replace("'","\'",$_POST['dateOfRegistration']);
		$dateOfIssuance = str_replace("'","\'",$_POST['dateOfIssuance']);
		$dateOfBirth = str_replace("'","\'",$_POST['dateOfBirth']);
		$gendar = str_replace("'","\'",$_POST['gendar']);
		$dateOfBirthText = str_replace("'","\'",$_POST['dateOfBirthText']);
		$nameBangla = base64_encode($_POST['nameBangla']);
		$nameEnglish = str_replace("'","\'",$_POST['nameEnglish']);
		$fatherNameBangla = base64_encode($_POST['fatherNameBangla']);
		$fatherNameEnglish = str_replace("'","\'",$_POST['fatherNameEnglish']);
		$fatherNationalityBangla = base64_encode($_POST['fatherNationalityBangla']);
		$fatherNationalityEnglish = str_replace("'","\'",$_POST['fatherNationalityEnglish']);
		$motherNameBangla = base64_encode($_POST['motherNameBangla']);
		$motherNameEnglish = str_replace("'","\'",$_POST['motherNameEnglish']);
		$motherNationalityBangla = base64_encode($_POST['motherNationalityBangla']);
		$motherNationalityEnglish = str_replace("'","\'",$_POST['motherNationalityEnglish']);
		$birthplaceBangla = base64_encode($_POST['birthplaceBangla']);
		$birthplaceEnglish = str_replace("'","\'",$_POST['birthplaceEnglish']);
		$permanentAddressBangla = base64_encode($_POST['permanentAddressBangla']);
		$permanentAddressEnglish = base64_encode($_POST['permanentAddressEnglish']);
		if(empty($dateOfBirthText)){$dateOfBirthText = dateTextAuto($dateOfBirth);}
		$cardID = intval(str2dec($_POST['cardID']));
		include "../assist/setting/autoLogin.php";
		$getLog = mysqli_query($conn,"SELECT * FROM `cards` WHERE `id` = $cardID");
		$totalLog = mysqli_num_rows($getLog);
		if($totalLog > 0){
			$row = mysqli_fetch_array($getLog);
			$updLog = mysqli_query($conn, "UPDATE `cards` SET `officeAddressFirst` = '$officeAddressFirst', `officeAddressSecond` = '$officeAddressSecond', `birthRegistrationNumber` = '$birthRegistrationNumber', `barCode` = '$barCode', `dateOfRegistration` = '$dateOfRegistration', `dateOfIssuance` = '$dateOfIssuance', `dateOfBirth` = '$dateOfBirth', `gendar` = '$gendar', `dateOfBirthText` = '$dateOfBirthText', `nameBangla` = '$nameBangla', `nameEnglish` = '$nameEnglish', `fatherNameBangla` = '$fatherNameBangla', `fatherNameEnglish` = '$fatherNameEnglish', `fatherNationalityBangla` = '$fatherNationalityBangla', `fatherNationalityEnglish` = '$fatherNationalityEnglish', `motherNameBangla` = '$motherNameBangla', `motherNameEnglish` = '$motherNameEnglish', `motherNationalityBangla` = '$motherNationalityBangla', `motherNationalityEnglish` = '$motherNationalityEnglish', `birthplaceBangla` = '$birthplaceBangla', `birthplaceEnglish` = '$birthplaceEnglish', `permanentAddressBangla` = '$permanentAddressBangla', `permanentAddressEnglish` = '$permanentAddressEnglish' WHERE `cards`.`id` = $cardID");
			if($updLog){
				$result['success'] = true;
				$result['link'] = $domain.$control['cpnale'].'&type=print&id='.str2enc($cardID);
			}else{
				$result['success'] = false;
				$result['message'] = 'সার্টিফিকেট আপডেট করতে ব্যর্থ!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'সার্টিফিকেট পাওয়া যায়নি!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>