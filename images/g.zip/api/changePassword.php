<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['newPassword'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$username = $_SESSION['adminID'];
		$newPassword = md5($_POST['newPassword']);
		$updatePassword = mysqli_query($conn, "UPDATE `admin` SET `password` = '$newPassword' WHERE `admin`.`username` = '$username'");
		if($updatePassword){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';				
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>