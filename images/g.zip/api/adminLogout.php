<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_POST['token'])){
	if(token2trust($_POST['token'])){
		session_destroy();
		$result['success'] = true;
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>