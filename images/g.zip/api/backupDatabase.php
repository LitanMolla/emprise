<?php
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_GET['token'])){
	if(token2trust($_GET['token'])){
		Export_Database();
	}else{
		echo '<script>alert("Invalid rand or token!");</script>';
	}
}else{
	echo '<script>alert("Invalid content for the request!");</script>';
}
?>