<?php
$result = [];
include "../assist/setting/index.php";
include "../assist/setting/autoLogin.php";

if(isset($_SESSION['userID'],$_POST['number'],$_POST['trxID'],$_POST['amount'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$userID = $user['id'];
		$userName = $user['name'];
		$number = $_POST['number'];
		$trxID = $_POST['trxID'];
		$amount = $_POST['amount'];
		newPaymentNotic($userID,$userName,$number,$trxID,$amount,'MANUEL');
		$newPay = mysqli_query($conn, "INSERT INTO `payments` (`id`, `userID`, `number`, `trxID`, `amount`, `type`, `status`, `date`) VALUES (NULL, '$userID', '$number', '$trxID', '$amount', 'MANUEL', 'PENDING', current_timestamp())");
		if($newPay){
			$result['success'] = true;
			$result['message'] = 'অ্যাডমিন অনুমোদনের জন্য অপেক্ষা করুন!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Failed to submit!';
		}	
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>