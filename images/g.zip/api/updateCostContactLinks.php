<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['cost'],$_POST['supportLink'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$cost = $_POST['cost'];
		$supportLink = $_POST['supportLink'];
		$updateApproval = mysqli_query($conn, "UPDATE `control` SET `cost` = '$cost', `supportLink` = '$supportLink' WHERE `control`.`id` = 1;");
		if($updateApproval){
			$result['success'] = true;
			$result['message'] = 'Update successfully!';
		}else{
			$result['success'] = false;
			$result['message'] = 'Something went worng!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>