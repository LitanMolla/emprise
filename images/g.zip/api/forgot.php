<?php
$result = [];
include "../assist/setting/index.php";

function getCode(){
	global $conn;
	$code = strtotime("+15 minutes",strtotime(date("Y-m-d H:i:s")));
	$checkCode = mysqli_query($conn, "SELECT * FROM `users` WHERE `code` = '$code'");
	$totalCode = mysqli_num_rows($checkCode);
	if($totalCode > 0){
		return getCode();
	}else{
		return $code;
	}
}

if(isset($_POST['email'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		$email = $_POST['email'];
		$checkList = mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '$email'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$listData = mysqli_fetch_array($checkList);
			$id = $listData['id'];
			$name = $listData['name'];
			$code = $listData['code'];
			if(strtotime(date("Y-m-d H:i:s")) > $code){
				$newCode = getCode();
				$link = $domain."reset&code=".str2enc($newCode);
				$subject = 'Password reset link request of '._MAIL_NAME_;
				$body = '<h3>Hello '.$name.',</h3><h4>We have received a password reset request for '._MAIL_NAME_.' from this mail. So we are providing you an one time link to reset your password.Open this link to your browser to reset your password.</h4><h4>Link: '.$link.'</h4><p style="color: #F44336;"><b>Note:</b> Do not share this link with anyone. Use this link within 15 minutes. This link is useless after 15 minutes. A link can only be used once.</p><br><center><p>If you did not request a password reset link, you can safely ignore this mail.</p></center>';
				$sendMail = sendMail($email,$subject,$body);
				if($sendMail){
					$updateStatus = mysqli_query($conn, "UPDATE `users` SET `code` = '$newCode' WHERE `users`.`id` = $id");
					if($updateStatus){
						$result['success'] = true;
						$result['message'] = 'Mail sent successfully!';
						$result['appMsg'] = "<spam style=\"color:#088d08;\">একটি পাসওয়ার্ড রিসেট লিঙ্ক আপনার ইমেল পাঠানো হয়েছে</spam><br><spam style=\"color:red;\">স্প্যাম/প্রচারমূলক মেইল চেক করতে ভুলবেন না। আপনি সেখানে লিঙ্ক খুঁজে পেতে পারেন </spam>";
					}else{
						$result['success'] = false;
						$result['message'] = 'Something went worng!';
					}
				}else{
					$result['success'] = false;
					$result['message'] = "Failed to send mail!";
				}
			}else{
				$result['success'] = false;
				$result['message'] = "Mail was sent!";
				$result['appMsg'] = "<spam style=\"color:#7066e0;\">আপনার পরবর্তী মেল পাঠাতে 15 মিনিট অপেক্ষা করুন</spam><br><spam style=\"color:red;\">স্প্যাম/প্রচারমূলক মেইল চেক করতে ভুলবেন না। আপনি সেখানে লিঙ্ক খুঁজে পেতে পারেন </spam>";
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Email doesn\'t exist!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>