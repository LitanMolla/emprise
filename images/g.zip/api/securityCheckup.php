<?php
include "../assist/setting/index.php";
$allFilesList = ["../.htaccess","../api/adminDelete.php","../api/adminLogin.php","../api/adminLogout.php","../api/approvePayment.php","../api/autoLoad.php","../api/backupDatabase.php","../api/bksLink.php","../api/bksPay.php","../api/changePassword.php","../api/delete.php","../api/deleteFile.php","../api/deleteUser.php","../api/forgot.php","../api/login.php","../api/logout.php","../api/manuelPay.php","../api/newCertifacate.php","../api/register.php","../api/rejectPayment.php","../api/report.php","../api/resetPass.php","../api/securityCheckup.php","../api/unverifyUser.php","../api/updateAdminCertifacate.php","../api/updateApproval.php","../api/updateBot.php","../api/updateCertifacate.php","../api/updateCostContactLinks.php","../api/updateNotice.php","../api/updatePassword.php","../api/updatePayment.php","../api/updateProfile.php","../api/updateServer.php","../api/updateUserBalance.php","../api/updateUserCost.php","../api/updateUserPassword.php","../api/verifyUser.php","../assist/css/birth.css","../assist/css/bootstrap.min.css","../assist/css/core.css","../assist/css/demo.css","../assist/css/new.css.map","../assist/css/style.css","../assist/css/theme-default.css","../assist/images/bg.svg","../assist/images/gbs.png","../assist/images/gradient-bg.png","../assist/images/icon.png","../assist/images/logo.png","../assist/images/min-icon.png","../assist/images/rgk.png","../assist/mail/Exception.php","../assist/mail/PHPMailer.php","../assist/mail/PHPMailerAutoload.php","../assist/mail/SMTP.php","../assist/mail/class.phpmailer.php","../assist/mail/class.phpmaileroauth.php","../assist/mail/class.phpmaileroauthgoogle.php","../assist/mail/class.smtp.php","../assist/script/JsBarcode.min.js","../assist/script/adminEdit.js","../assist/script/adminLogin.js","../assist/script/adminSideMenu.js","../assist/script/approvalSetting.js","../assist/script/backupSecurity.js","../assist/script/changePassword.js","../assist/script/costContactLinks.js","../assist/script/createNewAccount.js","../assist/script/edit.js","../assist/script/forgot.js","../assist/script/list-submission.js","../assist/script/login.js","../assist/script/new-submission.js","../assist/script/noticeSetting.js","../assist/script/password.js","../assist/script/paymentSetting.js","../assist/script/pendingPayments.js","../assist/script/profile.js","../assist/script/recharge.js","../assist/script/register.js","../assist/script/report.js","../assist/script/reset.js","../assist/script/serverSetting.js","../assist/script/submissionList.js","../assist/script/tgBotSetting.js","../assist/script/trust.min.js","../assist/script/users.js","../assist/setting/autoLogin.php","../assist/setting/birth.print.php","../assist/setting/bkash.merchant.php","../assist/setting/database.php","../assist/setting/domain.php","../assist/setting/function.php","../assist/setting/index.php","../assist/setting/mail.php","../assist/setting/simple_html_dom.php","../assist/setting/telegram.bot.php","../assist/setting/trust.min.php","../assist/thems/adminEdit.php","../assist/thems/adminLogin.php","../assist/thems/adminPrint.php","../assist/thems/adminSideMenu.php","../assist/thems/approvalSetting.php","../assist/thems/backupSecurity.php","../assist/thems/cancel-msg.php","../assist/thems/changePassword.php","../assist/thems/costContactLinks.php","../assist/thems/createNewAccount.php","../assist/thems/edit.php","../assist/thems/error-msg.php","../assist/thems/file-submission-list.php","../assist/thems/file-submission.php","../assist/thems/forgot.php","../assist/thems/licence.php","../assist/thems/login.php","../assist/thems/loginServerOff.php","../assist/thems/noticeSetting.php","../assist/thems/password.php","../assist/thems/paymentSetting.php","../assist/thems/paymentsHistory.php","../assist/thems/pendingPayments.php","../assist/thems/print.php","../assist/thems/profile.php","../assist/thems/recharge.php","../assist/thems/register.php","../assist/thems/registerServerOff.php","../assist/thems/report.php","../assist/thems/reset.php","../assist/thems/serverOff.php","../assist/thems/serverSetting.php","../assist/thems/share.php","../assist/thems/submissionList.php","../assist/thems/terms.php","../assist/thems/tgBotSetting.php","../assist/thems/trxid-msg.php","../assist/thems/userSideMenu.php","../assist/thems/users.php","../birth-maker.sql","../index.php"];

$result = $allFiles = $errorFiles = [];

if(isset($_SESSION['adminID'],$_POST['token'])){
	if(token2trust($_POST['token'])){
		getAllFiles(".."); getErrorFiles();
		if(count($errorFiles)){
			$result['success'] = true;
			$result['hasError'] = true;
			$result['message'] = 'Unknown file found!';
			$result['unknown'] = 'Find '.count($errorFiles).' unknown file';
			$errorFilesData = "";
			foreach($errorFiles as $file){
				$errorFilesData .= '<tr id="'.str2id($file,100).'"><td>'.basename($file).'</td><td>'.str_replace('../','',$file).'</td><td>'.sizeFile($file).'</td><td>'.mime_content_type($file).'</td><td><i id="deleteFile" data-id="'.str2enc($file).'" class="btn mb-1 btn-danger fa-solid fa-trash"></i></td></tr>';
			}
			$unknownFiles = '<div class="row"><h4 class="page-title mt-3 mb-3" style="font-weight: bold;">অজানা ফাইল</h4><div class="table-responsive"><table id="UnknownFilesList" class="table table-striped table-bordered" style="width:100%"><thead><tr><th class="text-center">Name</th><th class="text-center">Location</th><th class="text-center">Size</th><th class="text-center">Type</th><th class="text-center">Action</th></tr></thead><tbody align="center">'.$errorFilesData.'</tbody></table></div>';
			$result['unknownFiles'] = $unknownFiles;
		}else{
			$result['success'] = true;
			$result['hasError'] = false;
			$result['message'] = 'All files is secure!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>