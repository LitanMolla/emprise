<?php
$result = [];
include "../assist/setting/index.php";

if(isset($_SESSION['adminID'],$_POST['id'],$_POST['token'])){
	$id = str2dec($_POST['id']);
	if(token2trust($_POST['token']) && $id){
		$checkList = mysqli_query($conn, "SELECT * FROM `payments` WHERE `id` = '$id'");
    	$totalList = mysqli_num_rows($checkList);
		if($totalList > 0){
			$rejectPayment = mysqli_query($conn, "UPDATE `payments` SET `status` = 'REJECTED' WHERE `payments`.`id` = $id");
			if($rejectPayment){
				$result['success'] = true;
				$result['message'] = 'Rejected successfully!';
			}else{
				$result['success'] = false;
				$result['message'] = 'Something went worng!';
			}
		}else{
			$result['success'] = false;
			$result['message'] = 'Invalid payment ID!';
		}
	}else{
		$result['success'] = false;
		$result['message'] = 'Invalid rand or token!';
	}
}else{
	$result['success'] = false;
	$result['message'] = 'Invalid content for the request!';
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode($result));
?>