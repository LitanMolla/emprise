<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>New Birth Certificate</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<link href="<?php echo $domain; ?>assist/css/core.css" rel="stylesheet">
	<link href="<?php echo $domain; ?>assist/css/demo.css" rel="stylesheet">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<link href="<?php echo $domain; ?>assist/css/theme-default.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
</head>
<body>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
			<div id="menu-blur"></div>
			<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme"> 
				<div class="app-brand demo"> 
					<a class="app-brand-link"> 
						<span class="app-brand-logo demo">
							<img width="50px" src="assist/images/min-icon.png"> 
						</span> 
						<span class="app-brand-text menu-text fw-bolder ms-2">ONLINE SERVICE</span> 
					</a> 
				</div> 
				<ul class="menu-inner py-1"> 
					<?php include "userSideMenu.php"; ?>
				</ul> 
			</aside>
			<div class="layout-page">
				<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar"> 
					<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none"> 
						<a class="nav-item nav-link px-0 me-xl-4" id="layout-menu-btn"> 
							<i class="fa-solid fa-bars"></i> 
						</a> 
					</div> 
					<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse"> 
						<div class="navbar-nav align-items-center"> 
							<div class="nav-item d-flex align-items-center">
								<br> 
								<h4 style="margin-bottom: 0px;"><?php echo $user['name']; ?></h4> 
							</div> 
						</div> 
						<ul class="navbar-nav flex-row align-items-center ms-auto"> 
							<button type="button" class="btn btn-primary"> টাকা : <span id="balance"><?php echo $user['balance']; ?></span> </button> 
						</ul> 
					</div> 
				</nav>
				<div class="content-wrapper">
					<div class="container-xxl flex-grow-1 container-p-y">
						<div class="card mb-3">
							<marquee style="padding: 10px;background: white;border-radius: 5px;border: 1px solid #0d6efd;margin: 10px;width: calc(100% - 20px);"><?php echo base64_decode($control['notMsg']); ?></marquee>
						</div>
						<?php 
							if($cost > $user['balance']){
								echo '<div class="card mb-3"><p style="padding: 10px;text-align: center;background: white;border-radius: 5px;border: 1px solid #ff3e1d;margin: 10px;color: #ff3e1d;width: calc(100% - 20px);">'. base64_decode($control['lobMsg']) .'</p></div>';
							}
						?>
						<div class="card mb-3 container-xxl">
							<div class="row">
								<h4 class="page-title mt-3 mb-3" style="font-weight: bold;">নতুন  সার্টিফিকেট</h4>
							</div>
							<div class="row">
								<div class="col-md-12 mb-3 mt-3">
									<div id="autoLoad" class="col-md-6 container-xxl flex-grow-1 container-p-y">
										<div style="cursor: pointer;padding: 10px;text-align: center;background: white;border-radius: 20px;border: 3px dotted #2196F3;margin: 10px;color: #2196F3;width: calc(100% - 20px);">
											<i class="fa-duotone fa-memo-circle-info" style="font-size: 3rem;margin-top: 0.5rem;"></i>
											<h5 style="margin-top: 1rem;color: #2196F3;margin-bottom: 0.5rem;">স্বয়ংক্রিয়ভাবে ডেটা লোড করতে<br>এখানে ক্লিক করুন</h5>
										</div>
									</div>
								</div> 
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Register Office Address <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="officeAddressFirst" class="form-control" placeholder="রেজিস্টার অফিসের ঠিকানা" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Upazila/Pourashava/City Corporation, Zila <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="officeAddressSecond" class="form-control" placeholder="উপজেলা/পৌরসভা/সিটি কর্পোরেশন, জেলা" value=""> 
									</div> 
								</div> 
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Birth Registration Number <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="birthRegistrationNumber" placeholder="XXXXXXXXXXXXXXXXX" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Left Bar Code <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="barCode" placeholder="XXXXX" value=""> 
									</div> 
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Registration <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfRegistration" placeholder="DD/MM/YYYY" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Issuance <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfIssuance" placeholder="DD/MM/YYYY" value=""> 
									</div> 
								</div>
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Birth <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfBirth" placeholder="DD/MM/YYYY" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Gender <span style="color: #ff3e1d;">*</span></label> 
										<select id="gendar" class="form-control"> 
											<option value="Male">Male</option> 
											<option value="Female">Female</option> 
										</select> 
									</div> 
								</div>
							</div> 
							<div class="row">
								<div class="col-md-12 mb-3"> 
									<div class="form-group"> 
										<label>Date of Birth in Word</label> 
										<input type="text" class="form-control" id="dateOfBirthText" placeholder="Eleventh August two thousand three" value=""> 
									</div> 
								</div> 
							</div> 
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="nameBangla" class="form-control" placeholder="সম্পুর্ন নাম বাংলায়" value=""> 
									</div> 
								</div>  
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Name</label> 
										<input type="text" id="nameEnglish" class="form-control" placeholder="Full Name in English" value=""> 
									</div> 
								</div> 
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>পিতার নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="fatherNameBangla" class="form-control" placeholder="পিতার নাম বাংলায়" value=""> 
									</div> 
								</div>
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Father Name</label> 
										<input type="text" id="fatherNameEnglish" class="form-control" placeholder="Father Name in English" value=""> 
									</div> 
								</div>
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>পিতার জাতীয়তা</label> 
										<input type="text" class="form-control" id="fatherNationalityBangla" placeholder="পিতার জাতীয়তা বাংলায়" value="বাংলাদেশী"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Father Nationality</label> 
										<input type="text" class="form-control" id="fatherNationalityEnglish" placeholder="Father Nationality in English" value="Bangladeshi"> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>মাতার নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="motherNameBangla" class="form-control" placeholder="মাতার নাম বাংলায়" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Mother Name</label> 
										<input type="text" id="motherNameEnglish" class="form-control" placeholder="Mother Name in English" value=""> 
									</div> 
								</div> 
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>মাতার জাতীয়তা</label> 
										<input type="text" class="form-control" id="motherNationalityBangla" placeholder="মাতার জাতীয়তা বাংলায়" value="বাংলাদেশী"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 									
									<div class="form-group"> 
										<label>Mother Nationality</label> 
										<input type="text" class="form-control" id="motherNationalityEnglish" placeholder=">Mother Nationality in English" value="Bangladeshi"> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>জন্মস্থান <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="birthplaceBangla" placeholder="জন্মস্থান বাংলায়" value=""> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Place of Birth</label> 
										<input type="text" class="form-control" id="birthplaceEnglish" placeholder="Place of Birth in English" value=""> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>স্থায়ী ঠিকানা <span style="color: #ff3e1d;">*</span></label> 
										<textarea id="permanentAddressBangla" rows="4" class="form-control" placeholder="স্থায়ী ঠিকানা বাংলায়"></textarea>
									</div> 
								</div>
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Permanent Address</label> 
										<textarea id="permanentAddressEnglish" rows="4" class="form-control" placeholder="Permanent Address in English"></textarea>
									</div> 
								</div>
							</div>
							<a id="SavePrint" href="#SavePrint" class="btn btn-primary mb-3">Save & Print</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="autoLoadOptions">
		<div class="loaderBlurUltra"></div>
		<div class="popup card container-xxl">
			<i onClick="hideAutoLoadOptions();" class="close fa-solid fa-xmark"></i>
			<div class="row">
				<input type="hidden" id="cookie" readonly>
				<input type="hidden" id="CaptchaDeText" readonly>
				<input type="hidden" id="__RequestVerificationToken" readonly>
				<h4 class="page-title mt-3 mb-3 center" style="font-weight: bold;" align="center">Autoload Information</h4>
			</div>
			<div class="row"> 
				<div class="col-md-12 mb-3"> 
					<div class="form-group">
						<label>Birth Registration Number <span style="color: #ff3e1d;">*</span></label> 
						<input type="text" class="form-control" id="birthRegistrationNumberAutoLoad" placeholder="XXXXXXXXXXXXXXXXX" value=""> 
					</div> 
				</div> 
			</div>
			<div class="row">
				<div class="col-md-12 mb-3"> 
					<div class="form-group">
						<label>Date of Birth <span style="color: #ff3e1d;">*</span></label> 
						<input type="text" class="form-control" id="dateOfBirthAutoLoad" placeholder="YYYY-MM-DD" value="">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 mb-3">
					<div class="form-group">
						<label>Captcha Image</label>
						<center class="form-control">
							<img id="CaptchaDeImg" src="" style="max-width:100%;">
						</center>
					</div>
				</div>
			</div>
			<div class="row"> 
				<div class="col-md-12 mb-3">
					<div class="form-group"> 
						<label>Captcha Input Text <span style="color: #ff3e1d;">*</span></label> 
						<input type="text" class="form-control" id="captchaInputTextAutoLoad" placeholder="XX" value="">
					</div> 
				</div> 
			</div>
			<a id="loadData" href="#loadData" class="btn btn-primary mb-3">Load</a>
		</div>
	</div>
	<script>var cost = <?php echo $cost; ?>;</script>
	<script src="<?php echo $domain; ?>assist/script/new-submission.js?v1.1"></script>
</body>
</html>