<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link href="<?php echo $domain; ?>assist/css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
</head>
<body>
	<div class="top-bg"></div>
	<div class="bottom-bg"></div>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
    <div class="container">
		<div class="logo">
			<img src="assist/images/logo.png">
		</div>
		<div class="title">ইমেল এবং পাসওয়ার্ড দিয়ে লগ ইন করুন</div>
		<div class="input">
			<p>Email</p>
			<input type="email" id="email" placeholder="yourmail@gmail.com">
		</div>
		<div class="input">
			<p>Password</p>
			<input type="password" id="password" placeholder="********">
		</div>
		<div class="flex">
			<div class="remrmber">
				<input type="checkbox" class="remember" id="remember"> <p>Remember Me!</p>
			</div>
			<div class="forgot" onclick="location.href='<?php echo $domain; ?>forgot'">Forgotten password?</div>
		</div>
		<button class="button" id="login">LOGIN</button>
		<div class="new">Don't Have an Account? <span onclick="location.href='<?php echo $domain; ?>register'">Signup</span></div>
	</div>
	<script src="<?php echo $domain; ?>assist/script/login.js"></script>
	<?php include("assist/setting/auto.min.php");?>
</body>
</html>