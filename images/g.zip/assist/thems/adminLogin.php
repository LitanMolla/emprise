<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Admin Panel</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
	<style>body {height: 100%;width: 100%;background: #222D32;font-family: 'Roboto', sans-serif;}.container{position: fixed;top: 0;left: 0;right: 0;bottom: 0;height: 100%;width: 100%;z-index: 10;max-width: 100%;background: #222D32;}.scare {position: fixed;top: 0;left: 0;height: 100%;width: 100%;z-index: 1;}video {height: 100%;width: 100%;object-fit: cover;}.login-box {position: fixed;top: 50%;left: 50%;height: auto;background: #1A2226;text-align: center;box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23);transform: translate(-50%, -50%);max-width: 500px;width: 90%;}.login-key {height: 100px;font-size: 80px;line-height: 100px;background: -webkit-linear-gradient(#27EF9F, #0DB8DE);-webkit-background-clip: text;-webkit-text-fill-color: transparent;}.login-title {margin-top: 15px;text-align: center;font-size: 30px;letter-spacing: 2px;margin-top: 15px;font-weight: bold;color: #ECF0F5;}.login-form {margin-top: 25px;text-align: left;}input[type=text] {background-color: #1A2226;border: none;border-bottom: 2px solid #0DB8DE;border-top: 0px;border-radius: 0px;font-weight: bold;outline: 0;margin-bottom: 20px;padding-left: 0px;color: #ECF0F5;}input[type=password] {background-color: #1A2226;border: none;border-bottom: 2px solid #0DB8DE;border-top: 0px;border-radius: 0px;font-weight: bold;outline: 0;padding-left: 0px;margin-bottom: 20px;color: #ECF0F5;}.form-group {margin-bottom: 40px;outline: 0px;}.form-control:focus {border-color: inherit;-webkit-box-shadow: none;box-shadow: none;border-bottom: 2px solid #0DB8DE;outline: 0;background-color: #1A2226;color: #ECF0F5;}input:focus {outline: none;box-shadow: 0 0 0;}label {margin-bottom: 0px;}.form-control-label{font-size: 10px;color: #6C6C6C;font-weight: bold;letter-spacing: 1px;}.btn-outline-primary{border-color: #0DB8DE;color: #0DB8DE;border-radius: 0px;font-weight: bold;letter-spacing: 1px;box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);}.btn-outline-primary:hover {background-color: #0DB8DE;right: 0px;}.login-btm {float: left;}.login-button {padding-right: 0px;text-align: right;margin-bottom: 25px;}.login-text {text-align: left;padding-left: 0px;color: #F44336;}.loginbttm {padding: 0px;}</style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-2"></div>
			<div class="col-lg-6 col-md-8 login-box">
				<div class="col-lg-12 login-key">
					<i class="fa fa-key" aria-hidden="true"></i>
				</div>
				<div class="col-lg-12 login-title">ADMIN PANEL</div>
				<div class="col-lg-12 login-form">
					<div class="col-lg-12 login-form">
						<form>
							<div class="form-group">
								<label class="form-control-label">USERNAME</label>
								<input type="text" id="username" class="form-control">
							</div>
							<div class="form-group">
								<label class="form-control-label">PASSWORD</label>
								<input type="password" id="password" class="form-control">
							</div>
							<div class="col-lg-12 loginbttm">
								<div class="col-lg-6 login-btm login-text" id="error"></div>
								<div class="col-lg-6 login-btm login-button">
									<button type="submit" id="login" class="btn btn-outline-primary">LOGIN</button>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-lg-3 col-md-2"></div>
			</div>
		</div>
	</div>
	<script src="<?php echo $domain; ?>assist/script/adminLogin.js"></script>
</body>
</html>