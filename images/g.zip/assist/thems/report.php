<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Report - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<link href="<?php echo $domain; ?>assist/css/core.css" rel="stylesheet">
	<link href="<?php echo $domain; ?>assist/css/demo.css" rel="stylesheet">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<link href="<?php echo $domain; ?>assist/css/theme-default.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
</head>
<body>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
			<div id="menu-blur"></div>
			<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme"> 
				<div class="app-brand demo"> 
					<a class="app-brand-link"> 
						<span class="app-brand-logo demo">
							<img width="50px" src="assist/images/min-icon.png"> 
						</span> 
						<span class="app-brand-text menu-text fw-bolder ms-2">ONLINE SERVICE</span> 
					</a> 
				</div> 
				<ul class="menu-inner py-1"> 
					<?php include "userSideMenu.php"; ?>
				</ul> 
			</aside>
			<div class="layout-page">
				<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar"> 
					<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none"> 
						<a class="nav-item nav-link px-0 me-xl-4" id="layout-menu-btn"> 
							<i class="fa-solid fa-bars"></i> 
						</a> 
					</div> 
					<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse"> 
						<div class="navbar-nav align-items-center"> 
							<div class="nav-item d-flex align-items-center">
								<br> 
								<h4 style="margin-bottom: 0px;"><?php echo $user['name']; ?></h4> 
							</div> 
						</div> 
						<ul class="navbar-nav flex-row align-items-center ms-auto"> 
							<button type="button" class="btn btn-primary"> টাকা : <span id="balance"><?php echo $user['balance']; ?></span> </button> 
						</ul> 
					</div> 
				</nav>
				<div class="content-wrapper">
					<div class="container-xxl flex-grow-1 container-p-y">
						<div class="card mb-3 container-xxl">
							<div class="row">
								<h4 class="page-title mt-3 mb-3" style="font-weight: bold;">রিপোর্ট </h4>
							</div>
							<div class="row"> 
								<div class="col-md-12 mb-3"> 
									<div class="form-group"> 
										<label>সমস্যার বিষয় <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="subject" class="form-control"> 
									</div> 
								</div> 
							</div> 
							<div class="row"> 
								<div class="col-md-12 mb-3"> 
									<div class="form-group"> 
										<label>সমস্যার ব্যাখ্যা <span style="color: #ff3e1d;">*</span></label> 
										<textarea id="body" rows="5" class="form-control"></textarea>
									</div> 
								</div> 
							</div> 
							<a id="SubmitReport" href="#SubmitReport" class="btn btn-primary mb-3">Submit</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="<?php echo $domain; ?>assist/script/report.js"></script>
</body>
</html>