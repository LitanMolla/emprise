<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Rgister - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link href="<?php echo $domain; ?>assist/css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
</head>
<body>
	<div class="top-bg"></div>
	<div class="bottom-bg"></div>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
    <div class="container">
		<div class="logo">
			<img src="assist/images/logo.png">
		</div>
		<div class="title">একটি অ্যাকাউন্ট তৈরি করতে আপনার ব্যক্তিগত বিবরণ লিখুন</div>
		
		<div class="input">
			<p>Name</p>
			<input type="text" id="name" placeholder="Your Name">
		</div>
		
		<div class="input">
			<p>Email</p>
			<input type="email" id="email" placeholder="yourmail@gmail.com">
		</div>
		
		<div class="input">
			<p>Number</p>
			<input type="number" id="number" placeholder="01XXXXXXXXX">
		</div>
		
		<div class="input">
			<p>Password</p>
			<input type="password" id="password" placeholder="********">
		</div>
		
		<div class="input">
			<p>Confirm Password</p>
			<input type="password" id="cpassword" placeholder="********">
		</div>
		
		<div class="flex">
			<div class="remrmber">
				<input type="checkbox" id="agree"> <p>I agree with <span id="terms">terms & conditions</span></p>
			</div>
		</div>
		<button class="button" id="rgister">REGISTER</button>
		<div class="new">Already have an Account? <span onclick="location.href='<?php echo $domain; ?>login'">Signin</span></div>
	</div>
	<script src="<?php echo $domain; ?>assist/script/register.js"></script>
</body>
</html>