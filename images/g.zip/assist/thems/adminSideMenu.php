<li class="menu-item <?php if($type == "users"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "users"){echo "onclick=\"location.href='".$domain.$index."&type=users'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-users" aria-hidden="true"></i> 
		<div data-i18n="Analytics">ব্যবহারকারীর তালিকা</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "submissionList"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "submissionList"){echo "onclick=\"location.href='".$domain.$index."&type=submissionList'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-list" aria-hidden="true"></i>
		<div data-i18n="Analytics">সার্টিফিকেট লিস্ট</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "pendingPayments"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "pendingPayments"){echo "onclick=\"location.href='".$domain.$index."&type=pendingPayments'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-money-check-dollar-pen" aria-hidden="true"></i> 
		<div data-i18n="Analytics">অপেক্ষারত পেমেন্ট</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "paymentsHistory"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "paymentsHistory"){echo "onclick=\"location.href='".$domain.$index."&type=paymentsHistory'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-money-check-dollar" aria-hidden="true"></i> 
		<div data-i18n="Analytics">পেমেন্ট ইতিহাস</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "serverSetting"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "serverSetting"){echo "onclick=\"location.href='".$domain.$index."&type=serverSetting'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-gear" aria-hidden="true"></i> 
		<div data-i18n="Analytics">সার্ভার সেটিং</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "paymentSetting"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "paymentSetting"){echo "onclick=\"location.href='".$domain.$index."&type=paymentSetting'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-filter-circle-dollar" aria-hidden="true"></i>
		<div data-i18n="Analytics">পেমেন্ট সেটিং</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "tgBotSetting"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "tgBotSetting"){echo "onclick=\"location.href='".$domain.$index."&type=tgBotSetting'\"";} ?>> 
			<i class="menu-icon tf-icons fa-brands fa-telegram" aria-hidden="true"></i> 
		<div data-i18n="Analytics">টেলিগ্রাম বট সেটিং</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "approvalSetting"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "approvalSetting"){echo "onclick=\"location.href='".$domain.$index."&type=approvalSetting'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-user-police" aria-hidden="true"></i> 
		<div data-i18n="Analytics">অনুমোদন সেটিং</div> 
	</a> 
</li>
<li class="menu-item <?php if($type == "noticeSetting"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "noticeSetting"){echo "onclick=\"location.href='".$domain.$index."&type=noticeSetting'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-bell" aria-hidden="true"></i> 
		<div data-i18n="Analytics">নোটিশ সেটিং</div> 
	</a> 
</li>		
<li class="menu-item <?php if($type == "costContactLinks"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "costContactLinks"){echo "onclick=\"location.href='".$domain.$index."&type=costContactLinks'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-paperclip" aria-hidden="true"></i> 
		<div data-i18n="Analytics">খরচ & যোগাযোগ লিঙ্ক</div>
	</a> 
</li>		
<li class="menu-item <?php if($type == "changePassword"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "changePassword"){echo "onclick=\"location.href='".$domain.$index."&type=changePassword'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-lock" aria-hidden="true"></i> 
		<div data-i18n="Analytics">পাসওয়ার্ড পরিবর্তন করুন</div>
	</a> 
</li>
<li class="menu-item <?php if($type == "createNewAccount"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "createNewAccount"){echo "onclick=\"location.href='".$domain.$index."&type=createNewAccount'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-user-plus" aria-hidden="true"></i> 
		<div data-i18n="Analytics">নতুন অ্যাকাউন্ট তৈরি</div>
	</a> 
</li>	
<li class="menu-item <?php if($type == "backupSecurity"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "backupSecurity"){echo "onclick=\"location.href='".$domain.$index."&type=backupSecurity'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-shield-check" aria-hidden="true"></i> 
		<div data-i18n="Analytics">ব্যাকআপ এবং নিরাপত্তা</div>
	</a> 
</li>
<li class="menu-item <?php if($type == "licence"){echo "active";} ?>"> 
		<a class="menu-link" <?php if($type != "licence"){echo "onclick=\"location.href='".$domain.$index."&type=licence'\"";} ?>> 
			<i class="menu-icon tf-icons fas fa-file-certificate" aria-hidden="true"></i> 
		<div data-i18n="Analytics">লাইসেন্স</div>
	</a> 
</li>
<li class="menu-item"> 
	<a class="menu-link" id="logout"> 
		<i class="menu-icon fas fa-sign-out-alt" aria-hidden="true"></i> 
		<div data-i18n="Analytics">লগআউট </div> 
	</a> 
</li>
<script src="<?php echo $domain; ?>assist/script/adminSideMenu.js"></script>