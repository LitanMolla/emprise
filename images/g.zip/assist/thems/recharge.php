<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Recharge - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<link href="<?php echo $domain; ?>assist/css/core.css" rel="stylesheet">
	<link href="<?php echo $domain; ?>assist/css/demo.css" rel="stylesheet">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<link href="<?php echo $domain; ?>assist/css/theme-default.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
</head>
<body>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
			<div id="menu-blur"></div>
			<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme"> 
				<div class="app-brand demo"> 
					<a class="app-brand-link"> 
						<span class="app-brand-logo demo">
							<img width="50px" src="assist/images/min-icon.png"> 
						</span> 
						<span class="app-brand-text menu-text fw-bolder ms-2">ONLINE SERVICE</span> 
					</a> 
				</div> 
				<ul class="menu-inner py-1"> 
					<?php include "userSideMenu.php"; ?>
				</ul> 
			</aside>
			<div class="layout-page">
				<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar"> 
					<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none"> 
						<a class="nav-item nav-link px-0 me-xl-4" id="layout-menu-btn"> 
							<i class="fa-solid fa-bars"></i> 
						</a> 
					</div> 
					<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse"> 
						<div class="navbar-nav align-items-center"> 
							<div class="nav-item d-flex align-items-center">
								<br> 
								<h4 style="margin-bottom: 0px;"><?php echo $user['name']; ?></h4> 
							</div> 
						</div> 
						<ul class="navbar-nav flex-row align-items-center ms-auto"> 
							<button type="button" class="btn btn-primary"> টাকা : <span id="balance"><?php echo $user['balance']; ?></span> </button> 
						</ul> 
					</div> 
				</nav>
				<div class="content-wrapper">
					<div class="container-xxl flex-grow-1 container-p-y">
						<div class="card mb-3 container-xxl">
							<div class="row">
								<h4 class="page-title mt-3 mb-3" style="font-weight: bold;">রিচার্জ</h4>
								<?php if($control['rechargeType'] == "auto"){ ?>
								<div class="mb-3 container-xxl">
									<div class="form-group text-center mb-3">
										<h5 style="max-width:90%; margin:auto;"><?php echo preg_replace("/\r\n|\r|\n/", '<br/>', $control['recMsg']); ?></h5>
									</div>
									<div class="row"> 
										<div class="col-md-12 mb-3"> 
											<div class="form-group"> 
												<label>পরিমাণ <span style="color: #ff3e1d;">*</span></label> 
												<input type="number" id="amount" class="form-control" placeholder="সর্বনিম্ন রিচার্জ <?php echo $control['minRecharge']; ?> টাকা"> 
											</div> 
										</div> 
									</div>
									<a id="BKSPAY" href="#BKSPAY" class="btn btn-primary mb-3">Continue</a>
								</div>
								<div class="card-body col-sm-8 mx-auto"> 
									<h5 class="card-title">স্বয়ংক্রিয় ব্যালেন্স যোগ করুন</h5> 
									<ol class="list-group list-group-numbered"> 
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">200 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(200);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">300 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(300);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">500 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(500);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">1000 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(1000);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">1500 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(1500);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
										<li class="list-group-item d-flex justify-content-between align-items-start"> 
											<div class="mb-auto mt-auto ms-2 me-auto"> 
												<div class="fw-bold">2000 BDT</div> 
											</div> 
											<button type="submit" onClick="autoBksPay(2000);" class="btn btn-primary btn-sm ps-4 pe-4">Add</button> 
										</li>
									</ol> 
								</div>
								<?php }else{ ?>
								<div class="mb-3 container-xxl">
									<div class="form-group text-center mb-3">
										<h5 style="max-width:90%; margin:auto;"><?php echo preg_replace("/\r\n|\r|\n/", '<br/>', $control['recMsg']); ?></h5>
									</div>
									<div class="row"> 
										<div class="col-md-12 mb-3"> 
											<div class="form-group"> 
												<label>Number <span style="color: #ff3e1d;">*</span></label> 
												<input type="number" id="number" class="form-control" placeholder="XXXXXXXXXXX"> 
											</div> 
										</div> 
									</div>
									<div class="row"> 
										<div class="col-md-12 mb-3"> 
											<div class="form-group"> 
												<label>Transaction ID <span style="color: #ff3e1d;">*</span></label> 
												<input type="text" id="trxID" class="form-control" placeholder="XXXXXXXXX"> 
											</div> 
										</div> 
									</div>
									<div class="row"> 
										<div class="col-md-12 mb-3"> 
											<div class="form-group"> 
												<label>Amount <span style="color: #ff3e1d;">*</span></label> 
												<input type="number" id="amount" class="form-control" placeholder="সর্বনিম্ন রিচার্জ <?php echo $control['minRecharge']; ?> টাকা"> 
											</div> 
										</div> 
									</div>
									<a id="MANUELPAY" href="#MANUELPAY" class="btn btn-primary mb-3">Submit</a>
								</div>
								<?php } ?>
							</div>
						</div>
						<div class="card mb-3 container-xxl">
							<div class="row">
								<h4 class="page-title mt-3 mb-3" style="font-weight: bold;">রিচার্জ ইতিহাস</h4>
								<div class="table-responsive">
									<table id="RechargeList" class="table table-striped table-bordered" style="width:100%">
										<thead>
											<tr>
												<th class="text-center">SL</th>
												<th class="text-center">Number</th>
												<th class="text-center">Transaction</th>
												<th class="text-center">Amount</th>
												<th class="text-center">Type</th>
												<th class="text-center">Status</th>
												<th class="text-center">Date</th>
											</tr>
										</thead>
										<tbody align="center">
										<?php
											$userID = $_SESSION['userID'];
											$getList = mysqli_query($conn, "SELECT * FROM `payments` WHERE `userID` = '$userID' ORDER BY `payments`.`id` DESC");
											$totalList = mysqli_num_rows($getList);
											$cnt = 1;
											if($totalList > 0){
												while($rechargeList = mysqli_fetch_array($getList)){
										?>
											<tr>
												<td><?php echo $cnt; ?></td>
												<td><?php echo $rechargeList['number']; ?></td>
												<td><?php echo $rechargeList['trxID']; ?></td>
												<td><?php echo $rechargeList['amount']; ?></td>
												<td><?php echo $rechargeList['type']; ?></td>
												<td><?php echo $rechargeList['status']; ?></td>
												<td><?php echo $rechargeList['date']; ?></td>
											</tr>
										<?php $cnt = $cnt + 1;}} ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>var minRecharge = <?php echo $control['minRecharge']; ?>;</script>
	<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>	
	<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
	<script src="<?php echo $domain; ?>assist/script/recharge.js"></script>
</body>
</html>