<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Forgot Password - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<meta name="description" content="<?php echo $control['desMsg']; ?>">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link href="<?php echo $domain; ?>assist/css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
</head>
<body>
	<div class="top-bg"></div>
	<div class="bottom-bg"></div>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
    <div class="container">
		<div class="logo">
			<img src="assist/images/logo.png">
		</div>
		<div class="title">ইমেইল ব্যবহার করে পাসওয়ার্ড রিসেট করুন</div>
		<div class="input">
			<p>Email</p>
			<input type="email" id="email" placeholder="yourmail@gmail.com">
		</div>
		<button class="button" id="reset">SUBMIT</button>
		<div class="new">Don't Have an Account? <span onclick="location.href='<?php echo $domain; ?>register'">Signup</span></div>
	</div>
	<script src="<?php echo $domain; ?>assist/script/forgot.js"></script>
</body>
</html>