<li class="menu-item <?php if($index == "file-submission"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "file-submission"){echo "onclick=\"location.href='".$domain."file-submission'\"";} ?>> 
		<i class="menu-icon tf-icons fas fa-address-card" aria-hidden="true"></i> 
		<div data-i18n="Analytics">নতুন  সার্টিফিকেট</div>
	</a> 
</li>
<li class="menu-item <?php if($index == "file-submission-list"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "file-submission-list"){echo "onclick=\"location.href='".$domain."file-submission-list'\"";} ?>> 
		<i class="menu-icon fas fa-list" aria-hidden="true"></i> 
		<div data-i18n="Analytics">সার্টিফিকেট লিস্ট </div> 
	</a> 
</li>
<li class="menu-item <?php if($index == "recharge"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "recharge"){echo "onclick=\"location.href='".$domain."recharge'\"";} ?>> 
		<i class="menu-icon fas fa-square-dollar" aria-hidden="true"></i>
		<div data-i18n="Analytics">রিচার্জ</div> 
	</a> 
</li> 
<li class="menu-item <?php if($index == "profile"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "profile"){echo "onclick=\"location.href='".$domain."profile'\"";} ?>> 
		<i class="menu-icon fas fa-user" aria-hidden="true"></i> 
		<div data-i18n="Analytics">প্রোফাইল</div> 
	</a> 
</li> 
<li class="menu-item <?php if($index == "password"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "password"){echo "onclick=\"location.href='".$domain."password'\"";} ?>> 
		<i class="menu-icon fas fa-unlock-alt" aria-hidden="true"></i> 
		<div data-i18n="Analytics">পাসওয়ার্ড পরিবর্তন </div> 
	</a> 
</li> 
<li class="menu-item <?php if($index == "report"){echo "active";} ?>"> 
	<a class="menu-link" <?php if($index != "report"){echo "onclick=\"location.href='".$domain."report'\"";} ?>> 
		<i class="menu-icon fas fa-bug"" aria-hidden="true"></i>
		<div data-i18n="Analytics">রিপোর্ট </div> 
	</a> 
</li>
<li class="menu-item"> 
	<a class="menu-link" onclick="window.open('<?php echo $control['supportLink']; ?>', '_blank');"> 
		<i class="menu-icon fas fa-headset" aria-hidden="true"></i> 
		<div data-i18n="Analytics">সাপোর্ট </div> 
	</a> 
</li>
<li class="menu-item"> 
	<a class="menu-link" id="logout"> 
		<i class="menu-icon fas fa-sign-out-alt" aria-hidden="true"></i> 
		<div data-i18n="Analytics">লগআউট </div> 
	</a> 
</li>