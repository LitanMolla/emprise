<?php 
$code = str2dec($_GET['code']);

if($code){
	$checkCode = mysqli_query($conn, "SELECT * FROM `users` WHERE `code` = '$code'");
	$totalCode = mysqli_num_rows($checkCode);
	if($totalCode > 0){
		$listData = mysqli_fetch_array($checkCode);
		$id = $listData['id'];
		$code = $listData['code'];
		if(strtotime(date("Y-m-d H:i:s")) < $code){
			showReset(str2enc($id));
		}else{
			showError();
		}
	}else{
		showError();
	}
}else{
	showError();
}

function showError(){
	global $control,$domain;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Code Error</title>	
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
	<style>@import url('https://fonts.googleapis.com/css2?family=Lexend+Deca&family=Source+Sans+Pro&display=swap');* {   font-family: 'Source Sans Pro', sans-serif;	box-sizing: border-box;	webkit-box-sizing: border-box;    -moz-box-sizing: border-box;}</style>
</head>
<body style="background: #a0aec0;">
    <div style="position: absolute;top: 50%;left: 50%;color: #ffffff;background: #ffffff;transform: translate(-50%, -50%);max-width: 400px;width: 90%;border: 1px solid;border-radius: 10px;text-align: center;padding: 15px;">
		<i class="fa-solid fa-triangle-exclamation" style="font-size: 24px;color: #f5dc02;padding: 15px;background: #fff8b8;border-radius: 50%;margin: 5px;"></i>
		<h1 style="color: #FF9800;margin: 8px;">Code Error</h1>
		<h3 style="color: #2196F3;margin: 8px;">This link code already used or expired</h3>
		<a onclick="location.href='<?php echo $domain; ?>login'"><button style="width: 102px;height: 34px;color: #795548;margin: 8px;font-size: 18px;line-height: 34px;font-weight: bold;background: #b5b5b5;border: 0;border-radius: 10px;">OK</button></a>
	</div>
</body>
</html>
<?php 
} 
function showReset($userID){
	global $control,$domain;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login - Birth Certificate Maker</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link href="<?php echo $domain; ?>assist/css/style.css" rel="stylesheet">
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
</head>
<body>
	<div class="top-bg"></div>
	<div class="bottom-bg"></div>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
    <div class="container">
		<div class="logo">
			<img src="assist/images/logo.png">
		</div>
		<div class="title">একটি নতুন পাসওয়ার্ড তৈরি করুন</div>
		<div class="input">
			<p>New Password</p>
			<input type="password" id="newPassword" placeholder="********">
		</div>
		<div class="input">
			<p>Confion Password</p>
			<input type="password" id="conPassword" placeholder="********">
		</div>
		<button class="button" id="resetPass">Reset</button>
	</div>
	<script>var userID = '<?php echo $userID; ?>';</script>
	<script src="<?php echo $domain; ?>assist/script/reset.js"></script>
</script>
</body>
</html>
<?php } ?>