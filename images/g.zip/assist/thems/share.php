<?php
$id = str2dec($_GET['id']);

if($id){
	$getBirthList = mysqli_query($conn,"SELECT * FROM `cards` WHERE `id` = '$id'");
	$totalBirthList = mysqli_num_rows($getBirthList);
	if($totalBirthList > 0){
		$birthList = mysqli_fetch_array($getBirthList);
		ptintBirth($birthList);
	}else{
		notFound();
	}
}else{
	notFound();
}
?>