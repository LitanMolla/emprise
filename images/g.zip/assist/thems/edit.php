<?php
$cardID = str2dec($_GET['id']);
$userID = $_SESSION['userID'];

if($cardID){
	$getBirthList = mysqli_query($conn,"SELECT * FROM `cards` WHERE `id` = '$cardID' AND `userID` = '$userID'");
	$totalBirthList = mysqli_num_rows($getBirthList);
	if($totalBirthList > 0){
		$birthList = mysqli_fetch_array($getBirthList);
		editSubmission($birthList);
	}else{
		notFound();
	}
}else{
	notFound();
}

function notFound(){
	global $control,$domain;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Error</title>
	<meta charset="utf-8"/>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
	<style>@import url('https://fonts.googleapis.com/css2?family=Lexend+Deca&family=Source+Sans+Pro&display=swap');* {   font-family: 'Source Sans Pro', sans-serif;	box-sizing: border-box;	webkit-box-sizing: border-box;    -moz-box-sizing: border-box;}</style>
</head>
<body style="background: #a0aec0;">
    <div style="position: absolute;top: 50%;left: 50%;color: #ffffff;background: #ffffff;transform: translate(-50%, -50%);max-width: 400px;width: 90%;border: 1px solid;border-radius: 10px;text-align: center;padding: 15px;">
		<i class="fa-solid fa-triangle-exclamation" style="font-size: 24px;color: #f5dc02;padding: 15px;background: #fff8b8;border-radius: 50%;margin: 5px;"></i>
		<h1 style="color: #FF9800;margin: 8px;">Error</h1>
		<h3 style="color: #2196F3;margin: 8px;">সার্টিফিকেট পাওয়া যায়নি</h3>
		<a onClick="window.close();"><button style="width: 102px;height: 34px;color: #795548;margin: 8px;font-size: 18px;line-height: 34px;font-weight: bold;background: #b5b5b5;border: 0;border-radius: 10px;">OK</button></a>
	</div>
</body>
</html>
<?php
} 
function editSubmission($birthList){
	global $domain;
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Edit Birth Certificate</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<link href="<?php echo $domain; ?>assist/css/core.css" rel="stylesheet">
	<link href="<?php echo $domain; ?>assist/css/demo.css" rel="stylesheet">
	<script src="<?php echo $domain; ?>assist/script/trust.min.js"></script>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<link href="<?php echo $domain; ?>assist/css/theme-default.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
</head>
<body>
	<div id="loader">
		<div class="loaderBlur"></div>
		<div class="loaderSpinner"></div>
	</div>
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
			<div class="layout-page">
				<div class="content-wrapper">
					<div class="container-xxl flex-grow-1 container-p-y">
						<div class="card mb-3 container-xxl">
							<div class="row">
								<h4 class="page-title mt-3 mb-3" style="font-weight: bold;">সার্টিফিকেট সম্পাদনা করুন</h4>
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Register Office Address <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="officeAddressFirst" class="form-control" placeholder="রেজিস্টার অফিসের ঠিকানা" value="<?php echo $birthList['officeAddressFirst']; ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Upazila/Pourashava/City Corporation, Zila<span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="officeAddressSecond" class="form-control" placeholder="উপজেলা/পৌরসভা/সিটি কর্পোরেশন, জেলা" value="<?php echo $birthList['officeAddressSecond']; ?>"> 
									</div> 
								</div> 
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Birth Registration Number <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="birthRegistrationNumber" placeholder="XXXXXXXXXXXXXXXXX" value="<?php echo $birthList['birthRegistrationNumber']; ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Left Bar Code <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="barCode" placeholder="XXXXX" value="<?php echo $birthList['barCode']; ?>"> 
									</div> 
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Registration <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfRegistration" placeholder="DD/MM/YYYY" value="<?php echo $birthList['dateOfRegistration']; ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Issuance <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfIssuance" placeholder="DD/MM/YYYY" value="<?php echo $birthList['dateOfIssuance']; ?>"> 
									</div> 
								</div>
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Date of Birth <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="dateOfBirth" placeholder="DD/MM/YYYY" value="<?php echo $birthList['dateOfBirth']; ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Gender <span style="color: #ff3e1d;">*</span></label> 
										<select id="gendar" class="form-control">
											<?php if($birthList['gendar'] == 'Male'){ ?>
												<option value="Male">Male</option> 
												<option value="Female">Female</option>
											<?php }else{ ?>
												<option value="Female">Female</option>
												<option value="Male">Male</option> 
											<?php } ?>
										</select> 
									</div> 
								</div>
							</div> 
							<div class="row">
								<div class="col-md-12 mb-3"> 
									<div class="form-group"> 
										<label>Date of Birth in Word</label> 
										<input type="text" class="form-control" id="dateOfBirthText" placeholder="Eleventh August two thousand three" value="<?php echo $birthList['dateOfBirthText']; ?>"> 
									</div> 
								</div> 
							</div> 
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="nameBangla" class="form-control" placeholder="সম্পুর্ন নাম বাংলায়" readonly value="<?php echo base64_decode($birthList['nameBangla']); ?>"> 
									</div> 
								</div>  
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Name</label> 
										<input type="text" id="nameEnglish" class="form-control" placeholder="Full Name in English" value="<?php echo $birthList['nameEnglish']; ?>"> 
									</div> 
								</div> 
							</div> 
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>পিতার নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="fatherNameBangla" class="form-control" placeholder="পিতার নাম বাংলায়" value="<?php echo base64_decode($birthList['fatherNameBangla']); ?>"> 
									</div> 
								</div>
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Father Name</label> 
										<input type="text" id="fatherNameEnglish" class="form-control" placeholder="Father Name in English" value="<?php echo $birthList['fatherNameEnglish']; ?>"> 
									</div> 
								</div>
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>পিতার জাতীয়তা</label> 
										<input type="text" class="form-control" id="fatherNationalityBangla" placeholder="পিতার জাতীয়তা বাংলায়" value="<?php echo base64_decode($birthList['fatherNationalityBangla']); ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Father Nationality</label> 
										<input type="text" class="form-control" id="fatherNationalityEnglish" placeholder="Father Nationality in English" value="<?php echo $birthList['fatherNationalityEnglish']; ?>"> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>মাতার নাম <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" id="motherNameBangla" class="form-control" placeholder="মাতার নাম বাংলায়" value="<?php echo base64_decode($birthList['motherNameBangla']); ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Mother Name</label> 
										<input type="text" id="motherNameEnglish" class="form-control" placeholder="Mother Name in English" value="<?php echo $birthList['motherNameEnglish']; ?>"> 
									</div> 
								</div> 
							</div>
							<div class="row"> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>মাতার জাতীয়তা</label> 
										<input type="text" class="form-control" id="motherNationalityBangla" placeholder="মাতার জাতীয়তা বাংলায়" value="<?php echo base64_decode($birthList['motherNationalityBangla']); ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 									
									<div class="form-group"> 
										<label>Mother Nationality</label> 
										<input type="text" class="form-control" id="motherNationalityEnglish" placeholder=">Mother Nationality in English" value="<?php echo $birthList['motherNationalityEnglish']; ?>"> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>জন্মস্থান <span style="color: #ff3e1d;">*</span></label> 
										<input type="text" class="form-control" id="birthplaceBangla" placeholder="জন্মস্থান বাংলায়" value="<?php echo base64_decode($birthList['birthplaceBangla']); ?>"> 
									</div> 
								</div> 
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Place of Birth</label> 
										<input type="text" class="form-control" id="birthplaceEnglish" placeholder="Place of Birth in English" value="<?php echo $birthList['birthplaceEnglish']; ?>"> 
									</div> 
								</div> 
							</div>
							<div class="row">
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>স্থায়ী ঠিকানা <span style="color: #ff3e1d;">*</span></label> 
										<textarea id="permanentAddressBangla" rows="4" class="form-control" placeholder="স্থায়ী ঠিকানা বাংলায়"><?php echo base64_decode($birthList['permanentAddressBangla']); ?></textarea>
									</div> 
								</div>
								<div class="col-md-6 mb-3"> 
									<div class="form-group"> 
										<label>Permanent Address</label> 
										<textarea id="permanentAddressEnglish" rows="4" class="form-control" placeholder="Permanent Address in English"><?php echo base64_decode($birthList['permanentAddressEnglish']); ?></textarea>
									</div> 
								</div>
							</div>
							<a id="UpdatePrint" href="#UpdatePrint" class="btn btn-primary mb-3">Update & Print</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script>var cardID = "<?php echo str2enc($birthList['id']); ?>";</script>
	<script src="<?php echo $domain; ?>assist/script/edit.js"></script>
</body>
</html>
<?php
}
?>