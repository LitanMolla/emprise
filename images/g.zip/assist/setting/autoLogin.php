<?php
if($control['login']){
	if(isset($_SESSION['userID'])){
		$id = $_SESSION['userID'];
		if($control['approval']){
			$getUser = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' AND `status` = '1'");
		}else{
			$getUser = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id'");
		}
		$totalUser = mysqli_num_rows($getUser);
		if($totalUser > 0){
			$user = mysqli_fetch_array($getUser);
		}else{
			session_destroy();
		}
	}else if(isset($_COOKIE['userID'])){
		$id = str2dec($_COOKIE['userID']);
		if($id){
			if($control['approval']){
				$getUser = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id' AND `status` = '1'");
			}else{
				$getUser = mysqli_query($conn, "SELECT * FROM `users` WHERE `id` = '$id'");
			}
			$totalUser = mysqli_num_rows($getUser);
			if($totalUser > 0){
				$user = mysqli_fetch_array($getUser);
				$_SESSION['userID'] = $user['id'];
			}
		}else{
			session_destroy();
		}
	}
}

if(isset($_SESSION['userID'])){
	$id = $_SESSION['userID'];
	mysqli_query($conn, "UPDATE `users` SET `sync` = current_timestamp() WHERE `users`.`id` = $id");
}
?>