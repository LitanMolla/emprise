<?php
function bot($data, $method){
	$ch = curl_init('https://api.telegram.org/bot'.TG_BOT.'/'.$method);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch , CURLOPT_POSTFIELDS, $data);
	$res = curl_exec($ch); curl_close($ch);
	return json_decode($res,true);
}

function sendMessage($text){
	if(NOTIFY){
		$sendMessage = bot(['chat_id' => TG_ADMIN,'text' => $text,'reply_markup' => null,'parse_mode' => 'MarkDown'], 'sendMessage');
		return $sendMessage['ok'];
	}else{
		return false;
	}
}

function newRegisteredNotic($name,$email,$number){
	sendMessage("*__NEW_USER__*".PHP_EOL.PHP_EOL."*Name:* ".$name.PHP_EOL."*Email:* ".$email.PHP_EOL."*Number:* ".$number);
}

function newPaymentNotic($userID,$userName,$customerMsisdn,$trxID,$amount,$type){
	sendMessage("*__NEW_PAYMENT__*".PHP_EOL.PHP_EOL."*UserID:* ".$userID.PHP_EOL."*Name:* ".$userName.PHP_EOL."*Number:* ".$customerMsisdn.PHP_EOL."*TrxID:* ".$trxID.PHP_EOL."*Amount:* ".$amount.PHP_EOL."*Type:* ".$type);
}

function newReportNotic($userID,$userName,$subject,$body){
	return sendMessage("*__NEW_REPORT__*".PHP_EOL.PHP_EOL."*UserID:* ".$userID.PHP_EOL."*Name:* ".$userName.PHP_EOL.PHP_EOL."*Subject:* ".$subject.PHP_EOL."*Msg:* ".$body);
}

function newAdminLoginNotic($notic){sendMessage($notic);}
function newAdminServerUpdateNotic($notic){sendMessage($notic);}
?>