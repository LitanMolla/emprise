<?php
function removeFirstLastSpace($text){
	$firstWord = substr($text, 0, 1);
	$lastWord = substr($text, -1);
	if($firstWord == ' '){$text = substr($text, 1);}
	if($lastWord == ' '){$text = substr($text, 0 , -1);}
	return $text;
}

function removeSpace($text){
	$uniqText = preg_replace('/\s+/', ' ', str_replace(PHP_EOL,'',$text));
	$data = str_replace("  "," ",str_replace("	","",$uniqText));
	if(strpos($data , "  ") === false){
		return removeFirstLastSpace($data);
	}else{
		return removeSpace($data);
	}
}

function dateNumber($date){
	$monthWords = ['01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April', '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August', '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December', '/' => ' '];
	return str_replace(array_values($monthWords), array_keys($monthWords), $date);
}

function dayText($day){
	$dayWords = ['01' => 'First', '02' => 'Second', '03' => 'Third', '04' => 'Fourth', '05' => 'Fifth', '06' => 'Sixth', '07' => 'Seventh', '08' => 'Eighth', '09' => 'Ninth', '10' => 'Tenth', '11' => 'Eleventh', '12' => 'Twelfth', '13' => 'Thirteenth', '14' => 'Fourteenth', '15' => 'Fifteenth', '16' => 'Sixteenth', '17' => 'Seventeenth', '18' => 'Eighteenth', '19' => 'Nineteenth', '20' => 'Twentieth', '21' => 'Twenty first', '22' => 'Twenty second', '23' => 'Twenty third', '24' => 'Twenty fourth', '25' => 'Twenty fifth', '26' => 'Twenty sixth', '27' => 'Twenty seventh', '28' => 'Twenty eighth', '29' => 'Twenty ninth', '30' => 'Thirtieth', '31' => 'Thirtieth first'];
	return str_replace(array_keys($dayWords), array_values($dayWords), $day);
}

function monthText($date){
	$monthWords = ['01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April', '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August', '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December', '/' => ' '];
	return str_replace(array_keys($monthWords), array_values($monthWords), $date);
}

function yearText($year){
	$yearWords= ['0' => '',  '1' => 'One', '2' => 'Two', '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six', '7' => 'Seven', '8' => 'Eight', '9' => 'Nine', '10' => 'Ten'];
	$yearWordsSml= ['10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve', '13' => 'Thirteen', '14' => 'Fourteen', '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen', '18' => 'Eighteen', '19' => 'Nineteen', '20' => 'Twenty'];
	$yearWordsBig= ['0' => '', '2' => 'Twenty', '3' => 'Thirty', '4' => 'Forty', '5' => 'Fifty', '6' => 'Sixty', '7' => 'Seventy', '8' => 'Eighty', '9' => 'Ninety'];
		
	$th = intval($year[0].$year[1]);
	$ty = intval($year[2].$year[3]);

	if($th < 20){
		$thWord = 'Nineteen';
	}else{
		$thWord = 'Two Thousand';
	}
	
	if($ty < 10){
		$tyWord = str_replace(array_keys($yearWords), array_values($yearWords), $ty);
	}else if($ty < 20){
		$tyWord = str_replace(array_keys($yearWordsSml), array_values($yearWordsSml), $ty);
	}else{
		$tyWord = str_replace(array_keys($yearWordsBig), array_values($yearWordsBig), $year[2]) . ' ' . str_replace(array_keys($yearWords), array_values($yearWords), $year[3]);
	}
	
	return $thWord . ' ' . $tyWord;
}

function dateText($date){
	list($day, $month, $year) = explode(" ", $date);
	return removeSpace(dayText($day) . ' Of ' . $month . ' ' . yearText($year));
}

function dateTextAuto($date){
	list($day, $month, $year) = explode("/", $date);
	return removeSpace(dayText($day) . ' Of ' . monthText($month) . ' ' . yearText($year));
}

function getBarCode($code = null){
	$validCode = ['TIERM','TMHIZ','AQAQ','ZMMZA','TIAER'];
	$errorCode = 'https://bdris.gov.bd/certificate/verify?key=lUDVRCO8fF4+CEAZqhYMYtBDVDe3Gj0oyqNkbvRhjesQwjMDmD51Ifo1OrVbLUAs';

	$otherCode = [
		'ZMHEH' => 'https://bdris.gov.bd/certificate/verify?key=lUDVRCO8fF4+CEAZqhYMYtBDVDe3Gj0oyqNkbvRhjesQwjMDmD51Ifo1OrVbLUAs',
		'ZIMQM' => 'https://bdris.gov.bd/certificate/verify?key=4Fuk8+tvXb/UVSbqcm7VHizKMXEegODHSkuubmEAb3q+ruiTqK/SsM9A8hBrAHIC',
		'TMHDR' => 'https://bdris.gov.bd/certificate/verify?key=rxG8Rk2UYc5IQlM/CcGH5HSuhzmNt92ytveIX58tNuqGtepba+JAumOEgW7htz65',
		'TQEIH' => 'https://bdris.gov.bd/certificate/verify?key=TG6C63UjC+Ku9VvK1/UOrvfPvFqAHOcJHy3qJlAvtH1uHeyfrVTPi8+SxDCLldWO',
		'ZMZTM' => 'https://bdris.gov.bd/certificate/verify?key=POOxQZTCOlCZWRtdZmNdHIcC2I2Izb2+V5pRd7L6E+xsmCPa1MoCQsU5zhWtU8Cb',
		'TMMTI' => 'https://bdris.gov.bd/certificate/verify?key=pAEqiXFrk421fsiwjD9+1oeJ9d2PETNh3nP/LYjQdBWJB0NNQolwkbKG9qHmO8Oq',
	];

	$codeList = [
		'TIERM' => 'https://bdris.gov.bd/certificate/verify?key=9gM1hHQzEaKGmDeabQkopU6z2h3J19WFEHzwsZFkBnMDo5nkHHepJVuuu8syqtiy',
		'TMHIZ' => 'https://bdris.gov.bd/certificate/verify?key=VwAiz8wQaI1sbP2QLsgj5AjRGzTBbqtuOjnNiIhUCMl5UQkzRyTMC0St/w3LWlwX',
		'AQAQ' => 'https://bdris.gov.bd/certificate/verify?key=JQncefKVSLg0WjsdAitIzKzv2i9u4h1YqUzM9QY3eetWa1FfMmUa0PuXaGVMPAWs',
		'ZMMZA' => 'https://bdris.gov.bd/certificate/verify?key=gvI35NjCj25pqz1zX8e5xnysA6QAhW5ygnR8yolcXnPKCAjVQ5keqq6RWpDZ1ciG',
		'TIAER' => 'https://bdris.gov.bd/certificate/verify?key=f3sQtUEr5N5ETuPnCKxeXKQ7WcLglL4Bc4XMT2ehR7VeoBUJF/8mWi0GmXKtgqbm',
	];

    if($code == null){
        return $validCode[array_rand($validCode)];
    }else{
		if(isset($codeList[$code])){
			return $codeList[$code];
		}else if(isset($otherCode[$code])){
			return $otherCode[$code];
		}else{
			return $errorCode;
		}
	}
}
?>