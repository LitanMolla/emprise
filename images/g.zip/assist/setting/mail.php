<?php

define('_MAIL_NAME_','Birth Certificate Maker');
define('_MAIL_HOST_','everify.bdris.online');
define('_MAIL_USER_','otp@everify.bdris.online');
define('_MAIL_PASS_','systemma_everify');

function sendMail($email,$subject,$body){
	require(__DIR__.'/../mail/PHPMailerAutoload.php');
	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->Host = _MAIL_HOST_;
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "tls";
	$mail->Port = "587";
	$mail->Username = _MAIL_USER_;
	$mail->Password = _MAIL_PASS_;
	$mail->setFrom(_MAIL_USER_, _MAIL_NAME_);
	$mail->addReplyTo(_MAIL_USER_, 'No Reply');
	$mail->isHTML(true);
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->addAddress($email);
	if($mail->send()){
		return true;
	}else{
		return false;
	}
}

?>