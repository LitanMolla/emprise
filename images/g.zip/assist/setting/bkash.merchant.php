<?php
function getAuthToken(){
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, BKS_URL.'/checkout/token/grant');
	curl_setopt($curl, CURLOPT_POST, 1);
	curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(['app_key' => BKS_KEY,'app_secret' => BKS_SEC]));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER , 1);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type:application/json','username:'. BKS_USER,'password:'. BKS_PASS]);
	$content = curl_exec($curl);
    curl_close($curl);
    $response = json_decode($content, true);
	if($response['statusCode'] == "0000"){
		return $response['id_token'];
	}else{
		return null;
	} 
}

function createPaymentLink($amount){
	$authToken = getAuthToken();
	if($authToken != null){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, BKS_URL.'/checkout/create');
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(['mode' => '0011','amount' => $amount,'payerReference' => " ",'callbackURL' =>  DOMAIN."api/bksPay.php",'currency' => 'BDT','intent' => 'sale','merchantInvoiceNumber' => 'Inv'.rand()]));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER , 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type:application/json','Authorization:'. $authToken,'X-APP-Key:'. BKS_KEY]);
		$content = curl_exec($curl);
		curl_close($curl);
		$response = json_decode($content, true);
		if($response['statusCode'] == "0000"){
			return $response['bkashURL'];
		}else{
			return null;
		}
	}else{
		return null;
	}
}

function getPaymentDetils($paymentID){
	$authToken = getAuthToken();
	if($authToken != null){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, BKS_URL.'/checkout/execute');
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode(['paymentID' => $paymentID]));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER , 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type:application/json','Authorization:'. $authToken,'X-APP-Key:'. BKS_KEY]);
		$content = curl_exec($curl);
		curl_close($curl);
		$response = json_decode($content, true);
		if($response['statusCode'] == "0000"){
			$result = [];
			$result['success'] = true;
			$result['payerReference'] = $response['payerReference'];
			$result['customerMsisdn'] = $response['customerMsisdn'];
			$result['trxID'] = $response['trxID'];
			$result['amount'] = $response['amount'];
			$result['merchantInvoiceNumber'] = $response['merchantInvoiceNumber'];
			$result['paymentExecuteTime'] = $response['paymentExecuteTime'];
			return $result;
		}else{
			$result = [];
			$result['success'] = false;
			$result['statusMessage'] = $response['statusMessage'];
			return $result;
		}
	}else{
		return null;
	}
}
?>