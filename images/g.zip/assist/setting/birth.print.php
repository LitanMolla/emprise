<?php
function ptintBirth($birthList){
	global $domain;
?>
<html lang="en">
<head> 
	<meta charset="UTF-8">
	<title>birth-<?php echo $birthList['birthRegistrationNumber']; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="<?php echo $domain; ?>assist/script/JsBarcode.min.js"></script>
	<link rel="shortcut icon" href="<?php echo $domain; ?>assist/images/logo.png">
	<meta property="og:image" content="<?php echo $domain; ?>assist/images/icon.png">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdn.rawgit.com/sh4hids/bangla-web-fonts/solaimanlipi/stylesheet.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.0/css/bootstrap.min.css" integrity="sha512-NZ19NrT58XPK5sXqXnnvtf9T5kLXSzGQlVZL9taZWeTBtXoN3xIfTdxbkQh6QSoJfJgpojRqMfhyqBAAEeiXcA==" crossorigin="anonymous" referrerpolicy="no-referrer">
	<script>var birthRegistrationNumber = "<?php echo $birthList['birthRegistrationNumber']; ?>"; document.addEventListener('contextmenu', function (e) {e.preventDefault();});document.addEventListener('keydown', function (e) {if(e.ctrlKey){e.preventDefault();}});</script>
	<link rel="stylesheet" href="<?php echo $domain; ?>assist/css/birth.css">
	<style>@page {margin: 0;size: A4;}.bmarg{margin-top: -1px;} .bngla{font-family: SolaimanLipi!important;font-size: 17px!important;}</style>
</head>
<body>
	<div class="a4_page" id="a4_page">
		<div class="main_wrapper">
			<img src="<?php echo $domain; ?>assist/images/rgk.png" class="main_logo" alt="">
			<span style="z-index: 10;">
			<div class="mr_header">
					<div class="left_part_hidden"></div>
					<div class="left_part">
						<img style="height:110px; width:110px;" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&amp;data=<?php echo getBarCode($birthList['barCode']); ?>" alt="">
						<h2><?php echo $birthList['barCode']; ?></h2>
					</div>
					<div class="middle_part">
						<img src="<?php echo $domain; ?>assist/images/gbs.png" alt="" class="main_logo_r">
						<img src="<?php echo $domain; ?>assist/images/gbs.png" alt="" style="opacity: 0;">
						<h2>Government of the People’s Republic of Bangladesh</h2>
						<p class="office">Office of the Registrar, Birth and Death Registration</p>
						<p class="address1"><?php echo $birthList['officeAddressFirst']; ?></p>
						<p class="address2"><?php echo $birthList['officeAddressSecond']; ?></p>
						<p class="rule_y">(Rule 9, 10)</p>
						<h1><span class="bn" style="font-family: SolaimanLipi!important;font-size: 23px!important;">জন্ম নিবন্ধন সনদ /</span> <span class="en">Birth Registration Certificate</span></h1>
					</div>
					<div class="right_part_hidden"></div>
					<div class="right_part">
						<canvas style="height: 26px; width:220px;" id="barcode" width="310" height="120"></canvas>
					</div>
				</div>
				<div class="mr_body">
					<div class="top_part1">
						<div class="left">
							<p>Date of Registration</p>
							<p><?php echo $birthList['dateOfRegistration']; ?></p>
						</div>
						<div class="middle">
							<h2>Birth Registration Number</h2>
							<h1><?php echo $birthList['birthRegistrationNumber']; ?></h1>
						</div>
						<div class="right">
							<p>Date of Issuance</p>
							<p><?php echo $birthList['dateOfIssuance']; ?></p>
						</div>
					</div>
					<div class="middle">
						<div style="margin-top: 2px;margin-bottom: 5px;" class="new_td_2">
							<div class="left">
								<div class="part1">
									<p class="bn">Date of Birth<span style="margin-left: 42px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span class="bn"><?php echo $birthList['dateOfBirth']; ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p><span style="margin-left: 95px;" class="clone">Sex :</span></p>
								</div>
								<div class="part2">
									<p><span><?php echo $birthList['gendar']; ?></span></p>
								</div>
							</div>
						</div>
						<div style="margin-top: 5px;margin-bottom: 24px !important;" class="td">
							<div class="left">
								<div style="width: 130px;" class="part1">
									<p>In Word<span>:</span></p>
								</div>
								<div class="part2" style="width: 400px;">

									<p><span style="margin-left:5px"><?php echo $birthList['dateOfBirthText']; ?></span></p>
								</div>
							</div>
						</div>
						<div style="margin-top: 7px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">নাম<span style="margin-left: 103px;" class="clone">:</span></p>
								</div>
								<div class="part2" id="name_data_bn">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['nameBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="font-weight:500">Name<span style="margin-left: 95px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['nameEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div id="mother_content" style="margin-top: 17px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">মাতা<span style="margin-left: 98px;" class="clone">:</span></p>
								</div>
								<div class="part2" id="motherName_data_bn">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['motherNameBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="font-weight:500">Mother<span style="margin-left: 87px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['motherNameEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div id="motherNanality_content" style="margin-top: 17px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">মাতার জাতীয়তা<span style="margin-left: 26px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['motherNationalityBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="font-weight:500">Nationality<span style="margin-left: 64px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['motherNationalityEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div style="margin-top: 16px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">পিতা<span style="margin-left: 96px;" class="clone">:</span></p>
								</div>
								<div class="part2" id="fatherName_data_bn">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['fatherNameBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="font-weight:500">Father<span style="margin-left: 91px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['fatherNameEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div id="fatherNanality_content" style="margin-top: 17px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">পিতার জাতীয়তা<span style="margin-left: 26px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['fatherNationalityBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="font-weight:500">Nationality<span style="margin-left: 65px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['fatherNationalityEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div style="margin-top: 17px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">জন্মস্থান<span style="margin-left: 78px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo base64_decode($birthList['birthplaceBangla']); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="width: 153px; font-weight:500">Place of Birth<span style="margin-left: 46px;margin-right: 0;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo $birthList['birthplaceEnglish']; ?></span></p>
								</div>
							</div>
						</div>
						<div style="margin-top: 30px;" class="new_td">
							<div class="left">
								<div class="part1">
									<p class="bn" style="width: 146px;font-family: SolaimanLipi!important;font-size: 17px!important;margin-top: -2.5px;">স্থায়ী ঠিকানা<span style="margin-left:53px;margin-right: 0;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p style="margin-top: -2.5px;"><span class="bn" style="font-family: SolaimanLipi!important;font-size: 17px !important;"><?php echo nl2br(base64_decode($birthList['permanentAddressBangla'])); ?></span></p>
								</div>
							</div>
							<div class="right">
								<div class="part1">
									<p style="display:flex; width:154px; font-weight:500">Permanent<br>Address<span style="margin-left: 64px;" class="clone">:</span></p>
								</div>
								<div class="part2">
									<p><span style="font-weight:500"><?php echo nl2br(base64_decode($birthList['permanentAddressEnglish'])); ?></span></p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</span>
			<div class="mr_footer">
				<div class="top" style="margin-bottom: 57.5px;">
					<div class="left">
						<h2 style="width:10rem; margin-top: 0px;">Seal &amp; Signature</h2>
						<p style="margin-top: 0px;">Assistant to Registrar</p>
						<p style="margin-top: 0px;">(Preparation, Verification)</p>
					</div>
					<div class="right">
						<h2 style="width:10rem">Seal &amp; Signature</h2>
						<h2>
							<p>Registrar</p>
						</h2>
					</div>
				</div>
				<div class="bottom">
					<p>This certificate is generated from bdris.gov.bd, and to verify this certificate, please scan the above QR Code &amp; Bar Code.</p>
				</div>
			</div>
		</div>
	</div>
	<script>
		window.onload = function(){
			setBarcode();
			setSetting();
			setTimeout(wp, 500);
		}
		
		function setBarcode(){
			JsBarcode("#barcode", birthRegistrationNumber, {
				format: "CODE128",
				displayValue: false,
			});
		}
		
		function setSetting(){
			var elementWidth = $('#name_data_bn').height();
			if (Number(Math.floor(elementWidth)) > 23) {
				$('#mother_content').css("margin-top", "0px");
			}

			var elementWidth = $('#motherName_data_bn').height();
			if (Number(Math.floor(elementWidth)) > 23) {
				$('#motherNanality_content').css("margin-top", "0px");
			}

			var elementWidth = $('#fatherName_data_bn').height();
			if (Number(Math.floor(elementWidth)) > 23) {
				$('#fatherNanality_content').css("margin-top", "0px");
			}
		}
		
		function wp(){
			window.print();
		}
		
		window.addEventListener('click', function(){
			window.print();
		});
	</script>
</body>
</html>
<?php } ?>