<?php

define('DB_HOST','localhost');
define('DB_USER','bcmaker_db');
define('DB_PASS','bcmaker_db');
define('DB_NAME','bcmaker_db');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if(!$conn){
	if(isset($result)){
		$result['success'] = false;
		$result['message'] = "Databse connection lost";
		header('Content-Type: application/json; charset=utf-8');
		die(json_encode($result));
	}else{
		die('<script>alert("Databse connection lost");</script>');
	}
}

?>